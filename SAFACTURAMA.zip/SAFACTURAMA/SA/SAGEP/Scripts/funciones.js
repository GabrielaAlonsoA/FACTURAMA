﻿var arrMeses = ["MES", "Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
var IdDominioGlobal, DominioGlobal, IdCatalogoGlobal, ContolGlobal = "";
var DiaCerrarPresupuesto = "";
var FechaActualFormato = "";    
function FechaActual() {
    /// <summary>
    /// Regresa la fecha actual en formato YYYY-MM-DD
    /// </summary>
    /// <returns type="string">Fecha actual</returns>
    var date = new Date();
    var day = date.getDate(),
            month = date.getMonth() + 1,
            year = date.getFullYear(),
            hour = date.getHours(),
            min = date.getMinutes();

    month = (month < 10 ? "0" : "") + month;
    day = (day < 10 ? "0" : "") + day;
    hour = (hour < 10 ? "0" : "") + hour;
    min = (min < 10 ? "0" : "") + min;

    var today = year + "-" + month + "-" + day,
        time = hour + ":" + min;
    return today;
}

function obtener_fechas_semana(wNumSemana) {
    /// <summary>
    /// Regresa un arreglo con las fechas de la Semana indicada
    /// </summary>
    /// <param name="wNumSemana">Numero de la Semana del año</param>
    /// <returns type="string array">Arreglo con el listado de las fechas</returns>
    var fecha = new Date();
    var wAnio = fecha.getFullYear();
    resp = SAGEP.Ax_Utilerias.obtener_fechas_semana(wAnio.toString(), wNumSemana.toString());
    return resp.value;
}


function obtener_fecha_actual() {
    /// <summary>
    /// Regresa la fecha actual
    /// </summary>
    /// <returns type="string">Fecha actual</returns>
    var hoy = new Date();
    var dd = hoy.getDate();
    var mm = hoy.getMonth() + 1;
    var yyyy = hoy.getFullYear();

    if (dd < 10) dd = '0' + dd.toString();
    if (mm < 10) mm = '0' + mm.toString();

    return yyyy.toString() + "-" + mm + "-" + dd;
}

function formato_fecha(fecha) {
    var dia, mes, año, aux_mes, completa;
    try {
        fecha = fecha.trim();
        if (fecha != "") {
            datos = fecha.split('-');
            dia = datos[0];
            mes = datos[1];
            año = datos[2];
            switch (mes) {
                case '01':
                    aux_mes = 'Ene';
                    break;
                case '02':
                    aux_mes = 'Feb';
                    break;
                case '03':
                    aux_mes = 'Mar';
                    break;
                case '04':
                    aux_mes = 'Abr';
                    break;
                case '05':
                    aux_mes = 'May';
                    break;
                case '06':
                    aux_mes = 'Jun';
                    break;
                case '07':
                    aux_mes = 'Jul';
                    break;
                case '08':
                    aux_mes = 'Ago';
                    break;
                case '09':
                    aux_mes = 'Sep';
                    break;
                case '10':
                    aux_mes = 'Oct';
                    break;
                case '11':
                    aux_mes = 'Nov';
                    break;
                case '12':
                    aux_mes = 'Dic';
                    break;
            }
            completa = dia + '-' + aux_mes + '-' + año;
        }
        else {
            completa = '';
        }
    } catch (e) {
        completa = '';
    }

    if (completa == '-undefined-undefined' || dia === 'undefined' || aux_mes === 'undefined' || año === 'undefined') {
        completa = '';

    }

    return completa;
}


function formato_numero(num, separadorMil, separadorDec, signoMoneda) {
    /// <summary>
    /// Da formato a un número a moneda
    /// </summary>
    /// <param name="num">Número al que se le dará formato</param>
    /// <param name="separadorMil">Simbolo o caracter que se usará como separador de miles ej. ","</param>
    /// <param name="separadorDec">Simbolo o caracter que se usará como separador de decimales ej. "."</param>
    /// <param name="signoMoneda">Signo de moneada deseado ej. "$"</param>
    /// <returns type="string">Regresa el numero con el formato deseado</returns>
    sepMil = separadorMil;
    sepDec = separadorDec;
    simbol = signoMoneda;

    if (num == 0) {
        num = "0.00";
    }
    else {
        var num_aux = (num * 100).toFixed(2).toString();
        var pos = num_aux.lastIndexOf('.');
        if (pos != -1) {
            num_aux = num_aux.substring(0, pos);
        }
        num = num_aux.substring(0, num_aux.length - 2) + "." + num_aux.substring(num_aux.length - 2, num_aux.length);
    }
    if (sepMil == "") return num;
    num += '';
    var splitStr = num.split('.');
    var splitLeft = splitStr[0];
    var splitRight = splitStr.length > 1 ? sepDec + splitStr[1] : '';
    var regx = /(\d+)(\d{3})/;
    while (regx.test(splitLeft)) {
        splitLeft = splitLeft.replace(regx, '$1' + sepMil + '$2');
    }
    return simbol + splitLeft + splitRight;
}


function obt_per(mod) {
    //Verificar si se utiliza
    resp = MAP.Utilerias_Ax.buscar_permisos(mod);
    return resp.value;
}




function check_in(wmod, wopc, wmsg) {
    /// <summary>
    /// Revisa si el usuario tiene los permisos requeridos en el módulo
    /// </summary>
    /// <param name="wmod">Id del módulo</param>
    /// <param name="wopc">Opción seleccinada</param>
    /// <param name="wmsg">Bandera de permiso</param>
    /// <returns type="bool">Regresa False si no tiene los permisos o true si si cuenta con ellos</returns>

    lbl = document.getElementById("lbl_id").innerHTML;
    resp = SAGEP.Ax_Utilerias.check_in(lbl, wmod, wopc);
    if (resp.value == false) {
        if (wmsg == true)
        { alert("No tiene permiso para realizar esta operación"); }
    }
    return (resp.value);
}


function cerrar_sesion() {
    /// <summary>
    /// Cierra la sessión activa
    /// </summary>
    resp = SAGEP.AxAccesoS.cerrar_session();
    if (resp.value) {
        window.location.href = "Acceso.aspx";
        return;
    }
}

/*function campo_fecha(wcontrol) {
    /// <summary>
    /// Inicializa un textbox para que funcione como calendario de jquery
    /// </summary>
    /// <param name="wcontrol">Nombre o Id del control a obtener en formato jquery</param>
    $(wcontrol).datepicker({
        firstDay: 1,
        monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
        dayNamesMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sa'],
        dateFormat: "yy-mm-dd"
    });
}*/

function campo_fecha(wcontrol) {
    /// <summary>
    /// Inicializa un textbox para que funcione como calendario de jquery
    /// </summary>
    /// <param name="wcontrol">Nombre o Id del control a obtener en formato jquery</param>
    $(wcontrol).datepicker({
        firstDay: 1,
        monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
        monthNamesShort: ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"],
        dayNamesMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sa'],
        dateFormat: "dd-M-yy"
    });
}

function Trim(x) {
    /// <summary>
    /// Funcion Trim
    /// </summary>
    /// <param name="x">Cadena a la que se le quitaran los espacios en blanco</param>
    /// <returns type="">regresa la cadena sin espacios en blanco</returns>
    return x.replace(/^\s+|\s+$/gm, '');
}

function PadLeft(wCadena, wLong, wCaract) {
    /// <summary>
    /// Agrega un padding a la izquierda de una cadena
    /// </summary>
    /// <param name="wCadena">Cadena a la que se le agregará el padding</param>
    /// <param name="wLong">Longitud de la cadena</param>
    /// <param name="wCaract">Numero de caracteres de longitud de el padding a agregar</param>
    /// <returns type=""></returns>
    for (i = 1; i <= wLong - wCadena.length; i++)
        wCadena = wCaract + wCadena;
    return wCadena;
}



function limpiar_tabla(wtabla) {
    /// <summary>
    /// Limpia todos los rows de una tabla seleccionada
    /// </summary>
    /// <param name="wtabla">Nombre de la tabla a limpiar</param>

    if ($('#' + wtabla).length) {
        if (document.getElementById("Info_" + wtabla) != null) {
            document.getElementById("Info_" + wtabla).innerHTML = "";
        }
        var tabla = document.getElementById(wtabla);
        while (tabla.childNodes.length > 0) {
            var tr = tabla.childNodes.item(0);
            tr.parentNode.removeChild(tr);
        }
    } else {
        // no existe
    }

}


function llenar_ls_cat(wDominio, wIdCatalogoP, wControl, wNuevoItem) {
    /// <summary>
    /// Llena un select con la lista de items seleccionada de la tabla catalogo
    /// </summary>
    /// <param name="wDominio">Id del dominio al que pertenece el catálogo</param>
    /// <param name="wIdCatalogoP">Id del catálogo padre en caso de pertenecer a uno</param>
    /// <param name="wControl">Id del control select en el que se agregaran los items</param>
    /// <param name="wNuevoItem">Bandera en caso de permitir agregar nuevos items a la categoría</param>
    resp = SAGEP.Ax_Catalogo.buscar_elementos_catalogo(wDominio, wIdCatalogoP);
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wControl, wdt, "Catalogo", "IdCatalogo", "");
        if (wNuevoItem == true) {
            lista = document.getElementById(wControl);
            var opc = document.createElement("option");
            opc.innerHTML = "Nuevo Item";
            opc.setAttribute("value", "");
            lista.appendChild(opc);
            lista.setAttribute("onchange", "check_new_item_catalogo('" + wDominio + "','" + wdt.Rows[0]["Dominio"].toString() + "','" + wIdCatalogoP + "',this);");
        }
        lista.selectedIndex = -1;
    }
    else {
        alert("Error: No fue posible consultar el catalogo '" + wDominio + "'");
        return;
    }
}



function llenar_ls_cat_nuevo_item(wDominio, wIdCatalogoP, wControl, wNuevoItem) {
    /// <summary>
    /// Llena un select con la lista de items seleccionada de la tabla catalogo
    /// </summary>
    /// <param name="wDominio">Id del dominio al que pertenece el catálogo</param>
    /// <param name="wIdCatalogoP">Id del catálogo padre en caso de pertenecer a uno</param>
    /// <param name="wControl">Id del control select en el que se agregaran los items</param>
    /// <param name="wNuevoItem">Bandera en caso de permitir agregar nuevos items a la categoría</param>
    resp = SAGEP.Ax_Catalogo.buscar_elementos_catalogo(wDominio, wIdCatalogoP);
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wControl, wdt, "Catalogo", "IdCatalogo", "");
        if (wNuevoItem == true) {
            lista = document.getElementById(wControl);
            var opc = document.createElement("option");
            opc.innerHTML = "Nuevo Item";
            opc.setAttribute("value", "");
            lista.appendChild(opc);
            lista.setAttribute("onchange", "check_new_item_catalogo('" + wDominio + "','" + wDominio + "','" + wIdCatalogoP + "',this);");
        }
        lista.selectedIndex = -1;
    }
    else {
        alert("Error: No fue posible consultar el catalogo '" + wDominio + "'");
        return;
    }
}


function GuardarItem() {
    wCatalogo = document.getElementById("txt_Catalogo").value;
    wDescripcion = document.getElementById("txt_Descripcion").value;
    if (wCatalogo != "") {
        resp = SAGEP.Ax_Catalogo.agregar_NuevoItem(wCatalogo, wDescripcion, IdCatalogoGlobal, IdDominioGlobal);
        if (isNaN(resp.value) == false) {
            $("#dialog_nuevo_item_catalogo").modal('hide');
            llenar_ls_cat(IdDominioGlobal, IdCatalogoGlobal, ContolGlobal.id, true);
            seleccionar_ele_lista(ContolGlobal.id, wCatalogo, "");
        }
        else {
            alert("Error: " + resp.value);
        }
    }
    else {
        alert("Capture el nombre del nuevo elemento del catalogo");
        document.getElementById("txt_Catalogo").focus();
    }
}


function check_new_item_catalogo(wIdDominio, wDominio, wIdCatalogoP, wControl) {
    /// <summary>
    /// Abre dialogo para agregar un nuevo item al catalogo del select
    /// </summary>
    /// <param name="wIdDominio">Id del Dominio al que pertenece el catálogo</param>
    /// <param name="wDominio">Nombre del Dominio al que se agregará el nuevo item</param>
    /// <param name="wIdCatalogoP">Id del catálogo padre en caso de pertenecer a uno</param>
    /// <param name="wControl">Id del control select en el que se agregara el nuevo item</param>

    if (wControl.options[wControl.selectedIndex].innerHTML == "Nuevo Item") {

        var cad = "<table >";
        cad += "<tr><td style ='width:80px' ><span>Elemento:</span></td><td></td><td style ='width:250px'><input id = 'txt_Catalogo' style = 'width:100%'/></td></tr>";
        cad += "<tr><td style ='width:80px' ><span>Descripción:</span></td><td></td><td style ='width:250px'><input id = 'txt_Descripcion' style = 'width:100%'/></td></tr>";
        cad += "</table>";

        IdDominioGlobal=wIdDominio;
        DominioGlobal= wDominio;
        IdCatalogoGlobal = wIdCatalogoP;
        ContolGlobal = wControl;
        document.getElementById("nuevo_item_catalogo").innerHTML = cad;
        wDominio = "Nuevo elemento del Catálago(" + wDominio + ")";

        $("#dialog_nuevo_item_catalogo").modal("show");
       
       /* $("#dialog_nuevo_item_catalogo").dialog({ height: 160, width: 350, modal: true, autoOpen: false, title: wDominio,
            buttons:
                    [
                       {
                           text: "Aceptar", click: function () {

                               wCatalogo = document.getElementById("txt_Catalogo").value;
                               wDescripcion = document.getElementById("txt_Descripcion").value;
                               if (wCatalogo != "") {
                                   resp = SAGEP.Ax_Catalogo.agregar_NuevoItem(wCatalogo, wDescripcion, wIdCatalogoP, wIdDominio);
                                   if (isNaN(resp.value) == false) {
                                       $(this).dialog("close");
                                       llenar_ls_cat(wIdDominio, wIdCatalogoP, wControl.id, true);
                                       seleccionar_ele_lista(wControl.id, wCatalogo, "");
                                   }
                                   else {
                                       alert("Error: " + resp.value);
                                   }
                               }
                               else {
                                   alert("Capture el nombre del nuevo elemento del catalogo");
                                   document.getElementById("txt_Catalogo").focus();
                               }
                           }
                       },
                       {
                           text: "Cancelar",
                           click: function () {
                               wControl.selectedIndex = -1;
                               $(this).dialog("close");
                           }
                       }
                    ]
        });                 //fin inicializacion
        $("#dialog_nuevo_item_catalogo").dialog("open");*/
    }
}

function llenar_ls(ls_name, dtbl, text, valor, op_todos) {
    /// <summary>
    /// Llena un select con los valores indicados de un DataTable
    /// </summary>
    /// <param name="ls_name">Id del control select deseado</param>
    /// <param name="dtbl">DataTable con los datos a llenar</param>
    /// <param name="text">Nombre del campo a mostrar en la opción del select</param>
    /// <param name="valor">Nombre del campo a que será el valor de la opción del select </param>
    /// <param name="op_todos">Texto a mostrar en caso de querer una opción de seleccionar todos</param>
    /*limpiar_tabla(ls_name);
    lista = document.getElementById(ls_name);
    for (i = 0; i < dtbl.Rows.length; i++) {
        var opc = document.createElement("option");
        opc.innerHTML = dtbl.Rows[i][text].toString();
        opc.setAttribute("value", dtbl.Rows[i][valor].toString());
        lista.appendChild(opc);
    }
    if (op_todos != '') {
        opc = document.createElement("option");
        opc.innerHTML = op_todos;
        opc.setAttribute("value", "");
        lista.appendChild(opc);
    }
    lista.selectedIndex = -1;*/
    limpiar_tabla(ls_name);
    lista = document.getElementById(ls_name);
    for (i = 0; i < dtbl.Rows.length; i++) {
        var opc = document.createElement("option");
        opc.innerHTML = dtbl.Rows[i][text].toString();
        opc.setAttribute("value", dtbl.Rows[i][valor].toString());
        lista.appendChild(opc);
    }
    if (op_todos != '') {
        opc = document.createElement("option");
        opc.innerHTML = op_todos;
        opc.setAttribute("value", "");
        lista.appendChild(opc);
    }
    lista.selectedIndex = -1;
}


function agregar_ele_lista(ls_name, wtext, wvalor) {
    /// <summary>
    /// Agregar elementos a la lista de opciones de un select
    /// </summary>
    /// <param name="ls_name">Nombre de control select al que se le agregará</param>
    /// <param name="wtext">Texto que contendra la opción</param>
    /// <param name="wvalor">Nombre del valor que tendra la opción</param>
    lista = document.getElementById(ls_name);
    var opc = document.createElement("option");
    opc.innerHTML = wtext;
    opc.setAttribute("value", wvalor);
    lista.appendChild(opc);
}



function seleccionar_ele_lista(ls_name, wtext, wvalor) {
    /// <summary>
    /// Seleccionar un elemento de un control select
    /// </summary>
    /// <param name="ls_name">Nombre del control select</param>
    /// <param name="wtext">Texto de la opcion a seleccionar</param>
    /// <param name="wvalor">Valor de la opcion a seleccionar</param>
    /// <returns type="bool">Regresa true en caso de seleccionar el la opción, en caso de error regresa false</returns>
    lista = document.getElementById(ls_name);
    lista.selectedIndex = -1;
    if (wvalor == -1) {
        lista.selectedIndex = -1;
        return true;
    }

    for (i = 0; i < lista.length; i++) {
        if (wtext != "") {
            if (lista.options[i].innerHTML == wtext) {
                lista.selectedIndex = i;
                return true;
            }
        }
        if (wvalor != "") {
            if (lista.options[i].value == wvalor) {
                lista.selectedIndex = i;
                return true;
            }
        }

    }
    return false;
}

function limpiar_pantalla() {
    /// <summary>
    /// Recarga la página para limpiar la pantalla
    /// </summary>
    window.location.reload(true);
}


function obtener_ele_sel(nom_control) {
    /// <summary>
    /// Obtiene los elementos seleccionados de un control
    /// </summary>
    /// <param name="nom_control">Id del control de que se recuperaran los elementos seleccionados</param>
    /// <returns type="string">Cadena el nombre de los elementos seleccionados</returns>
    var cad = "";
    lista = document.getElementById(nom_control);
    for (i = 0; i < lista.length; i++) {
        if (lista.options[i].selected) {
            if (cad == "")
                cad = "'" + lista.options[i].innerHTML + "'";
            else cad = cad + ",'" + lista.options[i].innerHTML + "'";
        }
    }
    return cad;
}


function obtener_val_sel(nom_control) {
    /// <summary>
    /// Obtiene los valores de los elementos seleccionados de un control
    /// </summary>
    /// <param name="nom_control">Id del control de que se recuperaran los valores de elementos seleccionados</param>
    /// <returns type="string">Cadena los valores de los elementos seleccionados</returns>
    var cad = "";
    lista = document.getElementById(nom_control);
    for (i = 0; i < lista.length; i++) {
        if (lista.options[i].selected) {
            if (cad == "")
                cad = "'" + lista.options[i].value + "'";
            else cad = cad + ",'" + lista.options[i].value + "'";
        }
    }
    return cad;
}

/*****************************TABLA *******************************/
function crear_tabla(wDat_tbl, Nom_Tbl) {
    /// <summary>
    /// Crea una tabla Con el DataTable seleccionado
    /// </summary>
    /// <param name="wDat_tbl">DataTable con los datos de la tabla deseados</param>
    /// <param name="Nom_Tbl">Nombre de la tabla de la que se recuperará el esquema definido en la tabla cfgcols</param>
    var cad_tbl = "";
    nRegTabla = 0;
    resp = SAGEP.Ax_Utilerias.obtener_esquema_tbl(Nom_Tbl);
    wDef_tbl = resp.value;
    if (wDef_tbl != null && wDef_tbl.Rows != null) {
        if (wDef_tbl.Rows.length > 0) {
            cad_tbl = "<div style='text-align: center;width: '100%';' id='Info_" + Nom_Tbl + "'></div><table class='tables table-striped table-bordered table-sm' width='100%' style='text-align: center;' id='" + Nom_Tbl + "' cellpadding='0' align='center'> " +
        		              "<thead > <tr> ";
            for (i = 0; i < wDef_tbl.Rows.length; i++) {
                if (wDef_tbl.Rows[i]["visible"] == 1) {
                    cad_tbl = cad_tbl + " <th style = 'width:" + wDef_tbl.Rows[i]["ancho"].toString() + "'>" + wDef_tbl.Rows[i]["encab"].toString() + "</th>";
                }
                else {
                    cad_tbl = cad_tbl + " <th style = 'width:" + wDef_tbl.Rows[i]["ancho"].toString() + ";visibility:hidden;display:none;'>" + wDef_tbl.Rows[i]["encab"].toString() + "</th>";
                }

            }
            cad_tbl = cad_tbl + "</tr> </thead>";
            cad_tbl = cad_tbl + "<tbody id='" + Nom_Tbl + "_Det'></tbody></table>";
            document.getElementById("Div_" + Nom_Tbl).innerHTML = cad_tbl;
            document.getElementById("Div_" + Nom_Tbl).setAttribute("title", wDat_tbl.Rows.length);

            obj_ls = document.getElementById(Nom_Tbl + "_Det");
            for (i = 0; i < wDat_tbl.Rows.length; i++) {
                elmTR = document.createElement('tr');
                for (j = 0; j < wDef_tbl.Rows.length; j++) {
                    elmTD = document.createElement('td');
                    elmTD.style.width = wDef_tbl.Rows[j]["ancho"];
                    if (wDef_tbl.Rows[j]["visible"] == 1) {
                        elmTD.style.visibility = "visible";
                        //elmTD.setAttribute("display", "block");
                        //elmTD.attr('style', 'background-color:red')
                    }
                    else {
                        // elmTD.setAttribute("display", "none");
                        elmTD.style.visibility = "hidden";
                        elmTD.style.display = "none";
                    }

                    if (wDef_tbl.Rows[j]["predet"] == "D") elmTD.style.textAlign = "right";
                    if (j == 0)
                        nRegTabla++;
                    switch (wDef_tbl.Rows[j]["tipo"]) {
                        case "option":
                            elm = document.createElement('input');
                            elm.setAttribute("type", "radio");
                            elm.setAttribute("name", "SelOpt_" + Nom_Tbl);
                            elm.setAttribute("id", "SelOpt_" + Nom_Tbl + "_" + i.toString());

                            //Agregar evento en caso de que haya
                            if (wDef_tbl.Rows[j]["elep"] != "") {
                                obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                cad_funcion = obj_json.funcion + " (";
                                for (h = 0; h < obj_json.parametros.length; h++) {
                                    if (h != 0) cad_funcion = cad_funcion + ",";
                                    if (isNaN(obj_json.parametros[h].val_parametro.toString()))
                                        cad_funcion = cad_funcion + (obj_json.parametros[h].val_parametro.toString() == "this" ? obj_json.parametros[h].val_parametro.toString() : "'" + obj_json.parametros[h].val_parametro.toString() + "'");
                                    else
                                        cad_funcion = cad_funcion + "'" + wDat_tbl.Rows[i][wDef_tbl.Rows[obj_json.parametros[h].val_parametro.toString()]["columna"]] + "'";

                                }
                                cad_funcion = cad_funcion + ")";

                                elm.setAttribute(obj_json.evento, cad_funcion);
                            }


                            break;
                        case "checkbox":
                            elm = document.createElement('input');
                            elm.setAttribute("type", "checkbox");
                            elm.setAttribute("name", "Sel_" + Nom_Tbl);
                            elm.setAttribute("id", "Sel_" + Nom_Tbl + "_" + i.toString());
                            if (wDef_tbl.Rows[j]["columna"].toString() != "sel" && wDef_tbl.Rows[j]["columna"].toString() != "accion" && wDef_tbl.Rows[j]["columna"].toString() != "Sel") {
                                if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == true ||
                                    wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == "1") {
                                    elm.setAttribute("checked", true);
                                }
                            }



                            //Agregar evento en caso de que haya
                            if (wDef_tbl.Rows[j]["elep"] != "") {
                                obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                cad_funcion = obj_json.funcion + " (";
                                for (h = 0; h < obj_json.parametros.length; h++) {
                                    if (h != 0) cad_funcion = cad_funcion + ",";
                                    if (isNaN(obj_json.parametros[h].val_parametro.toString()))
                                        cad_funcion = cad_funcion + (obj_json.parametros[h].val_parametro.toString() == "this" ? obj_json.parametros[h].val_parametro.toString() : "'" + obj_json.parametros[h].val_parametro.toString() + "'");
                                    else
                                        cad_funcion = cad_funcion + "'" + wDat_tbl.Rows[i][wDef_tbl.Rows[obj_json.parametros[h].val_parametro.toString()]["columna"]] + "'";

                                }
                                cad_funcion = cad_funcion + ")";

                                elm.setAttribute(obj_json.evento, cad_funcion);
                            }
                            break;
                        case "checkbox-disabled":
                            elm = document.createElement('input');
                            elm.setAttribute("type", "checkbox");
                            elm.setAttribute("name", "Sel_" + Nom_Tbl);
                            elm.setAttribute("disabled", true);
                            elm.setAttribute("id", "Sel_" + Nom_Tbl + "_" + i.toString());
                            if (wDef_tbl.Rows[j]["columna"].toString() != "sel" && wDef_tbl.Rows[j]["columna"].toString() != "accion" && wDef_tbl.Rows[j]["columna"].toString() != "Sel") {
                                if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == true ||
                                    wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == "1") {
                                    elm.setAttribute("checked", true);

                                }
                            }



                            //Agregar evento en caso de que haya
                            if (wDef_tbl.Rows[j]["elep"] != "") {
                                obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                cad_funcion = obj_json.funcion + " (";
                                for (h = 0; h < obj_json.parametros.length; h++) {
                                    if (h != 0) cad_funcion = cad_funcion + ",";
                                    if (isNaN(obj_json.parametros[h].val_parametro.toString()))
                                        cad_funcion = cad_funcion + (obj_json.parametros[h].val_parametro.toString() == "this" ? obj_json.parametros[h].val_parametro.toString() : "'" + obj_json.parametros[h].val_parametro.toString() + "'");
                                    else
                                        cad_funcion = cad_funcion + "'" + wDat_tbl.Rows[i][wDef_tbl.Rows[obj_json.parametros[h].val_parametro.toString()]["columna"]] + "'";

                                }
                                cad_funcion = cad_funcion + ")";

                                elm.setAttribute(obj_json.evento, cad_funcion);
                            }
                            break;

                        case "checkboxPlanos":
                            elm = document.createElement('input');
                            elm.setAttribute("type", "checkbox");
                            elm.setAttribute("name", "Sel_" + Nom_Tbl);
                            elm.setAttribute("id", "Sel_" + Nom_Tbl + "_" + i.toString());
                            if (wDef_tbl.Rows[j]["columna"].toString() != "sel" && wDef_tbl.Rows[j]["columna"].toString() != "accion" && wDef_tbl.Rows[j]["columna"].toString() != "Sel") {
                                if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == true ||
                                    wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == "1") {
                                    elm.setAttribute("checked", true);
                                }
                            }
                            //Agregar evento en caso de que haya
                            if (wDef_tbl.Rows[j]["elep"] != "") {
                                obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                cad_funcion = obj_json.funcion + " (";
                                for (h = 0; h < obj_json.parametros.length; h++) {
                                    if (h != 0) cad_funcion = cad_funcion + ",";
                                    if (isNaN(obj_json.parametros[h].val_parametro.toString()))
                                        cad_funcion = cad_funcion + (obj_json.parametros[h].val_parametro.toString() == "this" ? obj_json.parametros[h].val_parametro.toString() : "'" + obj_json.parametros[h].val_parametro.toString() + "'");
                                    else
                                        cad_funcion = cad_funcion + "'" + wDat_tbl.Rows[i][wDef_tbl.Rows[obj_json.parametros[h].val_parametro.toString()]["columna"]] + "'";

                                }
                                cad_funcion = cad_funcion + ")";

                                elm.setAttribute(obj_json.evento, cad_funcion);
                            }
                            break;
                        case "checkboxtotal":
                            elm = document.createElement('input');
                            elm.setAttribute("type", "checkbox");
                            elm.setAttribute("name", "Sel_" + Nom_Tbl);
                            // elm.setAttribute("id", "Sel_" + Nom_Tbl + "_" + i.toString());
                            elm.setAttribute("id", wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()]);
                            if (wDef_tbl.Rows[j]["columna"].toString() != "sel" && wDef_tbl.Rows[j]["columna"].toString() != "accion" && wDef_tbl.Rows[j]["columna"].toString() != "Sel") {
                                if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == true ||
                                    wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == "1") {
                                    elm.setAttribute("checked", true);
                                }
                            }



                            //Agregar evento en caso de que haya
                            if (wDef_tbl.Rows[j]["elep"] != "") {
                                obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                cad_funcion = obj_json.funcion + " (";
                                for (h = 0; h < obj_json.parametros.length; h++) {
                                    if (h != 0) cad_funcion = cad_funcion + ",";
                                    if (isNaN(obj_json.parametros[h].val_parametro.toString()))
                                        cad_funcion = cad_funcion + (obj_json.parametros[h].val_parametro.toString() == "this" ? obj_json.parametros[h].val_parametro.toString() : "'" + obj_json.parametros[h].val_parametro.toString() + "'");
                                    else
                                        cad_funcion = cad_funcion + "'" + wDat_tbl.Rows[i][wDef_tbl.Rows[obj_json.parametros[h].val_parametro.toString()]["columna"]] + "'";

                                }
                                cad_funcion = cad_funcion + ")";

                                elm.setAttribute(obj_json.evento, cad_funcion);
                            }
                            break;
                        case "span":
                            elm = document.createElement('span');

                            if (wDef_tbl.Rows[j]["columna"].toString() == "rownumber")
                                elm.innerHTML = (i + 1).toString();
                            else
                                elm.innerHTML = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()];
                            elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());

                            break;
                        case "link":
                            if (wDef_tbl.Rows[j]["elep"] != "") {
                                elm = document.createElement('a');
                                elm.setAttribute("class", "span_link");
                                if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]] == null)
                                    elm.innerHTML = wDef_tbl.Rows[j]["columna"];
                                else
                                    elm.innerHTML = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]];

                                elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());

                                if (wDef_tbl.Rows[j]["elep"] != "") {
                                    obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                    cad_funcion = obj_json.funcion + " (";
                                    for (h = 0; h < obj_json.parametros.length; h++) {
                                        if (h != 0) cad_funcion = cad_funcion + ",";
                                        if (isNaN(obj_json.parametros[h].val_parametro.toString()))
                                            cad_funcion = cad_funcion + (obj_json.parametros[h].val_parametro.toString() == "this" ? obj_json.parametros[h].val_parametro.toString() : "'" + obj_json.parametros[h].val_parametro.toString() + "'");
                                        else
                                            cad_funcion = cad_funcion + "'" + wDat_tbl.Rows[i][wDef_tbl.Rows[obj_json.parametros[h].val_parametro.toString()]["columna"]] + "'";
                                    }
                                    cad_funcion = cad_funcion + ")";
                                    elm.setAttribute(obj_json.evento, cad_funcion);
                                }
                            }
                            break;
                        case "link-rep":
                            if (wDef_tbl.Rows[j]["elep"] != "") {
                                elm = document.createElement('a');
                                elm.setAttribute("class", "span_link");
                                /*if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]] == null)
                                elm.innerHTML = wDef_tbl.Rows[j]["columna"];
                                else*/
                                elm.innerHTML = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]];

                                elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());

                                if (wDef_tbl.Rows[j]["elep"] != "") {
                                    obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                    cad_funcion = obj_json.funcion + " (";
                                    for (h = 0; h < obj_json.parametros.length; h++) {
                                        if (h != 0) cad_funcion = cad_funcion + ",";
                                        if (obj_json.parametros[h].val_parametro.toString() == "0")
                                            cad_funcion = cad_funcion + "'" + j + "'";
                                        else
                                            cad_funcion = cad_funcion + "'" + wDat_tbl.Rows[i][wDef_tbl.Rows[obj_json.parametros[h].val_parametro.toString()]["columna"]] + "'";
                                    }
                                    cad_funcion = cad_funcion + ")";
                                    elm.setAttribute(obj_json.evento, cad_funcion);
                                }
                            }
                            break;
                        case "img":
                            elm = document.createElement('img');
                            elm.setAttribute("class", "span_link");
                            if (wDef_tbl.Rows[j]["elep"] != "") {
                                obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                cad_funcion = obj_json.funcion + " (";
                                for (h = 0; h < obj_json.parametros.length; h++) {
                                    if (h != 0) cad_funcion = cad_funcion + ",";
                                    cad_funcion = cad_funcion + "'" + wDat_tbl.Rows[i][wDef_tbl.Rows[obj_json.parametros[h].val_parametro.toString()]["columna"]] + "'";
                                }
                                cad_funcion = cad_funcion + ")";
                                elm.setAttribute(obj_json.evento, cad_funcion);
                                if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == null || wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == "")
                                    elm.setAttribute("src", "Images/" + obj_json.imgDef);
                                else
                                    elm.setAttribute("src", "Images/" + wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()]);
                                elm.setAttribute("width", obj_json.ancho);
                                elm.setAttribute("title", obj_json.title);
                            }

                            break;
                        case "select":
                            elm = document.createElement('select');
                            elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());
                            elm.style.width = "95%";
                            obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                            for (h = 0; h < obj_json.length; h++) {
                                var opt = document.createElement('option');
                                opt.innerHTML = obj_json[h].texto;
                                opt.setAttribute("value", obj_json[h].valor);
                                elm.appendChild(opt);
                            }

                            break;
                        case "select*":
                            elm = document.createElement('select');
                            elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());
                            elm.style.width = "95%"; //agregar el select

                            /*obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                            for (h = 0; h < obj_json.length; h++) {
                            var opt = document.createElement('option');
                            opt.innerHTML = obj_json[h].texto;
                            opt.setAttribute("value", obj_json[h].valor);
                            elm.appendChild(opt);
                            }*/

                            break;
                        case "text":
                            /*
                              
                            if (wDef_tbl.Rows[j]["columna"].toString() == "rownumber")
                            elm.innerHTML = (i + 1).toString();
                            else
                            elm.innerHTML = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()];
                            elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());
                            break;
                                
                            */

                            elm = document.createElement('input');
                            elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());
                            elm.setAttribute("type", "text");
                            if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]] != undefined)
                                elm.value = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]];
                            if (wDef_tbl.Rows[j]["predet"] == "D") elm.style.textAlign = "right";
                            elm.style.width = "95%";


                            break;
                        case "text-vol":
                            elm = document.createElement('input');
                            elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());
                            elm.setAttribute("type", "text");
                            if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]] != undefined) {
                                elm.value = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]];
                              //  elm.setAttribute("disabled", "disabled");
                            }
                            if (wDef_tbl.Rows[j]["predet"] == "D") elm.style.textAlign = "right";
                            elm.style.width = "95%";
                            break;
                        case "text-disabled":

                            elm = document.createElement('input');
                            elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());
                            elm.setAttribute("type", "text");
                            if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]] != undefined)
                                elm.value = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]];
                            if (wDef_tbl.Rows[j]["predet"] == "D") elm.style.textAlign = "right";
                            elm.style.width = "95%";
                            elm.disabled = true;


                            break;
                        case "date":
                            elm = document.createElement('span');
                            if (wDef_tbl.Rows[j]["columna"].toString() == "rownumber")
                                elm.innerHTML = (i + 1).toString();
                            else
                                elm.innerHTML = formato_fecha(wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()]);
                            elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());

                            break;
                        case "date-mod":
                            {
                                elm = document.createElement('input');
                                elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());
                                //elm.setAttribute("id", wDef_tbl.Rows[j]["columna"] + "_" + wDat_tbl.Rows[i][wDef_tbl.Rows[0]["columna"].toString()]); //
                                //wDef_tbl.Rows[0]["columna"] + "_" + wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] );
                                elm.setAttribute("type", "date");
                                elm.setAttribute("class", "datepicker__input");
                                elm.value = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()];
                                if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] != null) {
                                    elm.setAttribute("name", "modificado");
                                }
                                
                            }
                            break;
                        case "date-mod-edit":
                            {
                                elm = document.createElement('input');
                                elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());
                                elm.setAttribute("type", "date");
                                elm.setAttribute("class", "datepicker__input");
                                elm.value = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()];
                                if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] != null) {
                                    elm.setAttribute("name", "modificado");
                                   // elm.setAttribute("disabled", "disabled");
                                }
                            }

                            break;
                        case "money":
                            elm = document.createElement('span');

                            if (wDef_tbl.Rows[j]["columna"].toString() == "rownumber")
                                elm.innerHTML = (i + 1).toString();
                            else
                                elm.innerHTML = formato_numero((wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()]), ",", ".", "$");
                            elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());

                            break;
                        default:
                            elm = document.createElement('span');
                            elm.innerHTML = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]];

                            break;
                    }

                    elmTD.appendChild(elm);
                    elmTR.appendChild(elmTD);
                } //For definicion de tablas (Columnas)
                obj_ls.appendChild(elmTR);
            } //For Datos
            $('#' + Nom_Tbl).fixedHeaderTable({ altClass: 'odd', footer: false, autoresize: true });
        }
        else {
            alert("Error: No esta definido el esquema de la tabla '" + Nom_Tbl + "'");
        }
    }
    else {
        alert("Error: No se pudo accesar al esquema de la tabla '" + Nom_Tbl + "'");
    }
}

function crear_tabla_totales(wDat_tbl, Nom_Tbl) {
    /// <summary>
    /// Crea una tabla Con el DataTable seleccionado
    /// </summary>
    /// <param name="wDat_tbl">DataTable con los datos de la tabla deseados</param>
    /// <param name="Nom_Tbl">Nombre de la tabla de la que se recuperará el esquema definido en la tabla cfgcols</param>
    var bandTotal = false;
    var cad_tbl = "";
    nRegTabla = 0;
    resp = SAGEP.Ax_Utilerias.obtener_esquema_tbl(Nom_Tbl);
    wDef_tbl = resp.value;
    if (wDef_tbl != null && wDef_tbl.Rows != null) {
        if (wDef_tbl.Rows.length > 0) {
            cad_tbl = "<div style='text-align: center;width: '100%';' id='Info_" + Nom_Tbl + "'></div><div style='text-align: center;width: '100%';' id='Info_" + Nom_Tbl + "'></div><table class='tables table-striped table-bordered table-sm' width='100%' style='text-align: center;' id='" + Nom_Tbl + "' cellpadding='0' align='center'> " +
        		              "<thead > <tr> ";
            for (i = 0; i < wDef_tbl.Rows.length; i++) {
                if (wDef_tbl.Rows[i]["visible"] == 1) {
                    cad_tbl = cad_tbl + " <th style = 'width:" + wDef_tbl.Rows[i]["ancho"].toString() + "'>" + wDef_tbl.Rows[i]["encab"].toString() + "</th>";
                }
                else {
                    cad_tbl = cad_tbl + " <th style = 'width:" + wDef_tbl.Rows[i]["ancho"].toString() + ";visibility:hidden;display:none;'>" + wDef_tbl.Rows[i]["encab"].toString() + "</th>";
                }

            }
            cad_tbl = cad_tbl + "</tr> </thead>";
            cad_tbl = cad_tbl + "<tbody id='" + Nom_Tbl + "_Det'></tbody></table>";
            document.getElementById("Div_" + Nom_Tbl).innerHTML = cad_tbl;
            document.getElementById("Div_" + Nom_Tbl).setAttribute("title", wDat_tbl.Rows.length);

            obj_ls = document.getElementById(Nom_Tbl + "_Det");
            for (i = 0; i < wDat_tbl.Rows.length; i++) {
                elmTR = document.createElement('tr');
                bandTotal = false;
                for (j = 0; j < wDef_tbl.Rows.length; j++) {
                    if (j == 0) {
                        nameCol = wDat_tbl.Columns[j].Name;
                        var auxD = wDat_tbl.Rows[i][nameCol];
                        if (auxD == null) {
                            bandTotal = true;
                        }
                    }

                    elmTD = document.createElement('td');
                    elmTD.style.width = wDef_tbl.Rows[j]["ancho"];
                    if (wDef_tbl.Rows[j]["visible"] == 1) {
                        elmTD.style.visibility = "visible";
                        //elmTD.setAttribute("display", "block");
                        //elmTD.attr('style', 'background-color:red')
                    }
                    else {
                        // elmTD.setAttribute("display", "none");
                        elmTD.style.visibility = "hidden";
                        elmTD.style.display = "none";
                    }

                    if (wDef_tbl.Rows[j]["predet"] == "D") elmTD.style.textAlign = "right";
                    if (!bandTotal) {
                        if (j == 0)
                            nRegTabla++;
                        switch (wDef_tbl.Rows[j]["tipo"]) {
                            case "option":
                                elm = document.createElement('input');
                                elm.setAttribute("type", "radio");
                                elm.setAttribute("name", "SelOpt_" + Nom_Tbl);
                                elm.setAttribute("id", "SelOpt_" + Nom_Tbl + "_" + i.toString());

                                //Agregar evento en caso de que haya
                                if (wDef_tbl.Rows[j]["elep"] != "") {
                                    obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                    cad_funcion = obj_json.funcion + " (";
                                    for (h = 0; h < obj_json.parametros.length; h++) {
                                        if (h != 0) cad_funcion = cad_funcion + ",";
                                        if (isNaN(obj_json.parametros[h].val_parametro.toString()))
                                            cad_funcion = cad_funcion + (obj_json.parametros[h].val_parametro.toString() == "this" ? obj_json.parametros[h].val_parametro.toString() : "'" + obj_json.parametros[h].val_parametro.toString() + "'");
                                        else
                                            cad_funcion = cad_funcion + "'" + wDat_tbl.Rows[i][wDef_tbl.Rows[obj_json.parametros[h].val_parametro.toString()]["columna"]] + "'";

                                    }
                                    cad_funcion = cad_funcion + ")";

                                    elm.setAttribute(obj_json.evento, cad_funcion);
                                }


                                break;
                            case "checkbox":
                                elm = document.createElement('input');
                                elm.setAttribute("type", "checkbox");
                                elm.setAttribute("name", "Sel_" + Nom_Tbl);
                                elm.setAttribute("id", "Sel_" + Nom_Tbl + "_" + i.toString());
                                if (wDef_tbl.Rows[j]["columna"].toString() != "sel" && wDef_tbl.Rows[j]["columna"].toString() != "accion" && wDef_tbl.Rows[j]["columna"].toString() != "Sel") {
                                    if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == true ||
                                    wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == "1") {
                                        elm.setAttribute("checked", true);
                                    }
                                }



                                //Agregar evento en caso de que haya
                                if (wDef_tbl.Rows[j]["elep"] != "") {
                                    obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                    cad_funcion = obj_json.funcion + " (";
                                    for (h = 0; h < obj_json.parametros.length; h++) {
                                        if (h != 0) cad_funcion = cad_funcion + ",";
                                        if (isNaN(obj_json.parametros[h].val_parametro.toString()))
                                            cad_funcion = cad_funcion + (obj_json.parametros[h].val_parametro.toString() == "this" ? obj_json.parametros[h].val_parametro.toString() : "'" + obj_json.parametros[h].val_parametro.toString() + "'");
                                        else
                                            cad_funcion = cad_funcion + "'" + wDat_tbl.Rows[i][wDef_tbl.Rows[obj_json.parametros[h].val_parametro.toString()]["columna"]] + "'";

                                    }
                                    cad_funcion = cad_funcion + ")";

                                    elm.setAttribute(obj_json.evento, cad_funcion);
                                }
                                break;
                            case "checkbox-disabled":
                                elm = document.createElement('input');
                                elm.setAttribute("type", "checkbox");
                                elm.setAttribute("name", "Sel_" + Nom_Tbl);
                                elm.setAttribute("disabled", true);
                                elm.setAttribute("id", "Sel_" + Nom_Tbl + "_" + i.toString());
                                if (wDef_tbl.Rows[j]["columna"].toString() != "sel" && wDef_tbl.Rows[j]["columna"].toString() != "accion" && wDef_tbl.Rows[j]["columna"].toString() != "Sel") {
                                    if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == true ||
                                    wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == "1") {
                                        elm.setAttribute("checked", true);

                                    }
                                }



                                //Agregar evento en caso de que haya
                                if (wDef_tbl.Rows[j]["elep"] != "") {
                                    obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                    cad_funcion = obj_json.funcion + " (";
                                    for (h = 0; h < obj_json.parametros.length; h++) {
                                        if (h != 0) cad_funcion = cad_funcion + ",";
                                        if (isNaN(obj_json.parametros[h].val_parametro.toString()))
                                            cad_funcion = cad_funcion + (obj_json.parametros[h].val_parametro.toString() == "this" ? obj_json.parametros[h].val_parametro.toString() : "'" + obj_json.parametros[h].val_parametro.toString() + "'");
                                        else
                                            cad_funcion = cad_funcion + "'" + wDat_tbl.Rows[i][wDef_tbl.Rows[obj_json.parametros[h].val_parametro.toString()]["columna"]] + "'";

                                    }
                                    cad_funcion = cad_funcion + ")";

                                    elm.setAttribute(obj_json.evento, cad_funcion);
                                }
                                break;

                            case "checkboxPlanos":
                                elm = document.createElement('input');
                                elm.setAttribute("type", "checkbox");
                                elm.setAttribute("name", "Sel_" + Nom_Tbl);
                                elm.setAttribute("id", "Sel_" + Nom_Tbl + "_" + i.toString());
                                if (wDef_tbl.Rows[j]["columna"].toString() != "sel" && wDef_tbl.Rows[j]["columna"].toString() != "accion" && wDef_tbl.Rows[j]["columna"].toString() != "Sel") {
                                    if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == true ||
                                    wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == "1") {
                                        elm.setAttribute("checked", true);
                                    }
                                }
                                //Agregar evento en caso de que haya
                                if (wDef_tbl.Rows[j]["elep"] != "") {
                                    obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                    cad_funcion = obj_json.funcion + " (";
                                    for (h = 0; h < obj_json.parametros.length; h++) {
                                        if (h != 0) cad_funcion = cad_funcion + ",";
                                        if (isNaN(obj_json.parametros[h].val_parametro.toString()))
                                            cad_funcion = cad_funcion + (obj_json.parametros[h].val_parametro.toString() == "this" ? obj_json.parametros[h].val_parametro.toString() : "'" + obj_json.parametros[h].val_parametro.toString() + "'");
                                        else
                                            cad_funcion = cad_funcion + "'" + wDat_tbl.Rows[i][wDef_tbl.Rows[obj_json.parametros[h].val_parametro.toString()]["columna"]] + "'";

                                    }
                                    cad_funcion = cad_funcion + ")";

                                    elm.setAttribute(obj_json.evento, cad_funcion);
                                }
                                break;
                            case "checkboxtotal":
                                elm = document.createElement('input');
                                elm.setAttribute("type", "checkbox");
                                elm.setAttribute("name", "Sel_" + Nom_Tbl);
                                // elm.setAttribute("id", "Sel_" + Nom_Tbl + "_" + i.toString());
                                elm.setAttribute("id", wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()]);
                                if (wDef_tbl.Rows[j]["columna"].toString() != "sel" && wDef_tbl.Rows[j]["columna"].toString() != "accion" && wDef_tbl.Rows[j]["columna"].toString() != "Sel") {
                                    if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == true ||
                                    wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == "1") {
                                        elm.setAttribute("checked", true);
                                    }
                                }



                                //Agregar evento en caso de que haya
                                if (wDef_tbl.Rows[j]["elep"] != "") {
                                    obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                    cad_funcion = obj_json.funcion + " (";
                                    for (h = 0; h < obj_json.parametros.length; h++) {
                                        if (h != 0) cad_funcion = cad_funcion + ",";
                                        if (isNaN(obj_json.parametros[h].val_parametro.toString()))
                                            cad_funcion = cad_funcion + (obj_json.parametros[h].val_parametro.toString() == "this" ? obj_json.parametros[h].val_parametro.toString() : "'" + obj_json.parametros[h].val_parametro.toString() + "'");
                                        else
                                            cad_funcion = cad_funcion + "'" + wDat_tbl.Rows[i][wDef_tbl.Rows[obj_json.parametros[h].val_parametro.toString()]["columna"]] + "'";

                                    }
                                    cad_funcion = cad_funcion + ")";

                                    elm.setAttribute(obj_json.evento, cad_funcion);
                                }
                                break;
                            case "span":
                                elm = document.createElement('span');

                                if (wDef_tbl.Rows[j]["columna"].toString() == "rownumber")
                                    elm.innerHTML = (i + 1).toString();
                                else
                                    elm.innerHTML = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()];
                                elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());

                                break;
                            case "link":
                                if (wDef_tbl.Rows[j]["elep"] != "") {
                                    elm = document.createElement('a');
                                    elm.setAttribute("class", "span_link");
                                    if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]] == null)
                                        elm.innerHTML = wDef_tbl.Rows[j]["columna"];
                                    else
                                        elm.innerHTML = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]];

                                    elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());

                                    if (wDef_tbl.Rows[j]["elep"] != "") {
                                        obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                        cad_funcion = obj_json.funcion + " (";
                                        for (h = 0; h < obj_json.parametros.length; h++) {
                                            if (h != 0) cad_funcion = cad_funcion + ",";
                                            if (isNaN(obj_json.parametros[h].val_parametro.toString()))
                                                cad_funcion = cad_funcion + (obj_json.parametros[h].val_parametro.toString() == "this" ? obj_json.parametros[h].val_parametro.toString() : "'" + obj_json.parametros[h].val_parametro.toString() + "'");
                                            else
                                                cad_funcion = cad_funcion + "'" + wDat_tbl.Rows[i][wDef_tbl.Rows[obj_json.parametros[h].val_parametro.toString()]["columna"]] + "'";
                                        }
                                        cad_funcion = cad_funcion + ")";
                                        elm.setAttribute(obj_json.evento, cad_funcion);
                                    }
                                }
                                break;
                            case "link-rep":
                                if (wDef_tbl.Rows[j]["elep"] != "") {
                                    elm = document.createElement('a');
                                    elm.setAttribute("class", "span_link");
                                    /*if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]] == null)
                                    elm.innerHTML = wDef_tbl.Rows[j]["columna"];
                                    else*/
                                    elm.innerHTML = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]];

                                    elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());

                                    if (wDef_tbl.Rows[j]["elep"] != "") {
                                        obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                        cad_funcion = obj_json.funcion + " (";
                                        for (h = 0; h < obj_json.parametros.length; h++) {
                                            if (h != 0) cad_funcion = cad_funcion + ",";
                                            if (obj_json.parametros[h].val_parametro.toString() == "0")
                                                cad_funcion = cad_funcion + "'" + j + "'";
                                            else
                                                cad_funcion = cad_funcion + "'" + wDat_tbl.Rows[i][wDef_tbl.Rows[obj_json.parametros[h].val_parametro.toString()]["columna"]] + "'";
                                        }
                                        cad_funcion = cad_funcion + ")";
                                        elm.setAttribute(obj_json.evento, cad_funcion);
                                    }
                                }
                                break;
                            case "img":
                                elm = document.createElement('img');
                                elm.setAttribute("class", "span_link");
                                if (wDef_tbl.Rows[j]["elep"] != "") {
                                    obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                    cad_funcion = obj_json.funcion + " (";
                                    for (h = 0; h < obj_json.parametros.length; h++) {
                                        if (h != 0) cad_funcion = cad_funcion + ",";
                                        cad_funcion = cad_funcion + "'" + wDat_tbl.Rows[i][wDef_tbl.Rows[obj_json.parametros[h].val_parametro.toString()]["columna"]] + "'";
                                    }
                                    cad_funcion = cad_funcion + ")";
                                    elm.setAttribute(obj_json.evento, cad_funcion);
                                    if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == null || wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] == "")
                                        elm.setAttribute("src", "Images/" + obj_json.imgDef);
                                    else
                                        elm.setAttribute("src", "Images/" + wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()]);
                                    elm.setAttribute("width", obj_json.ancho);
                                    elm.setAttribute("title", obj_json.title);
                                }

                                break;
                            case "select":
                                elm = document.createElement('select');
                                elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());
                                elm.style.width = "95%";
                                obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                for (h = 0; h < obj_json.length; h++) {
                                    var opt = document.createElement('option');
                                    opt.innerHTML = obj_json[h].texto;
                                    opt.setAttribute("value", obj_json[h].valor);
                                    elm.appendChild(opt);
                                }

                                break;
                            case "select*":
                                elm = document.createElement('select');
                                elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());
                                elm.style.width = "95%"; //agregar el select

                                /*obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                for (h = 0; h < obj_json.length; h++) {
                                var opt = document.createElement('option');
                                opt.innerHTML = obj_json[h].texto;
                                opt.setAttribute("value", obj_json[h].valor);
                                elm.appendChild(opt);
                                }*/

                                break;
                            case "text":
                                /*
                              
                                if (wDef_tbl.Rows[j]["columna"].toString() == "rownumber")
                                elm.innerHTML = (i + 1).toString();
                                else
                                elm.innerHTML = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()];
                                elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());
                                break;
                                
                                */

                                elm = document.createElement('input');
                                elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());
                                elm.setAttribute("type", "text");
                                if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]] != undefined)
                                    elm.value = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]];
                                if (wDef_tbl.Rows[j]["predet"] == "D") elm.style.textAlign = "right";
                                elm.style.width = "95%";


                                break;
                            case "text-vol":
                                elm = document.createElement('input');
                                elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());
                                elm.setAttribute("type", "text");
                                if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]] != undefined) {
                                    elm.value = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]];
                                    //  elm.setAttribute("disabled", "disabled");
                                }
                                if (wDef_tbl.Rows[j]["predet"] == "D") elm.style.textAlign = "right";
                                elm.style.width = "95%";
                                break;
                            case "text-disabled":

                                elm = document.createElement('input');
                                elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());
                                elm.setAttribute("type", "text");
                                if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]] != undefined)
                                    elm.value = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]];
                                if (wDef_tbl.Rows[j]["predet"] == "D") elm.style.textAlign = "right";
                                elm.style.width = "95%";
                                elm.disabled = true;


                                break;
                            case "date":
                                elm = document.createElement('span');
                                if (wDef_tbl.Rows[j]["columna"].toString() == "rownumber")
                                    elm.innerHTML = (i + 1).toString();
                                else
                                    elm.innerHTML = formato_fecha(wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()]);
                                elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());

                                break;
                            case "date-mod":
                                {
                                    elm = document.createElement('input');
                                    elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());
                                    //elm.setAttribute("id", wDef_tbl.Rows[j]["columna"] + "_" + wDat_tbl.Rows[i][wDef_tbl.Rows[0]["columna"].toString()]); //
                                    //wDef_tbl.Rows[0]["columna"] + "_" + wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] );
                                    elm.setAttribute("type", "date");
                                    elm.setAttribute("class", "datepicker__input");
                                    elm.value = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()];
                                    if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] != null) {
                                        elm.setAttribute("name", "modificado");
                                    }

                                }
                                break;
                            case "date-mod-edit":
                                {
                                    elm = document.createElement('input');
                                    elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());
                                    elm.setAttribute("type", "date");
                                    elm.setAttribute("class", "datepicker__input");
                                    elm.value = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()];
                                    if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()] != null) {
                                        elm.setAttribute("name", "modificado");
                                        // elm.setAttribute("disabled", "disabled");
                                    }
                                }

                                break;
                            case "money":
                                elm = document.createElement('span');

                                if (wDef_tbl.Rows[j]["columna"].toString() == "rownumber")
                                    elm.innerHTML = (i + 1).toString();
                                else
                                    elm.innerHTML = formato_numero((wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()]), ",", ".", "$");
                                elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());

                                break;
                            default:
                                elm = document.createElement('span');
                                elm.innerHTML = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]];

                                break;
                        }
                    }
                    else {
                        if (j == 0) {
                            elm = document.createElement('span');
                            nameCol = wDat_tbl.Columns[j].Name;
                            elm.innerHTML = "Total";
                            elm.setAttribute("id", Nom_Tbl + nameCol + "_" + i.toString());
                            elm.setAttribute("class", "renglonTotal");
                        }
                        else {
                            elm = document.createElement('span');
                            nameCol = wDat_tbl.Columns[j].Name;
                            if (wDat_tbl.Rows[i][nameCol] == null) {
                                elm.innerHTML = wDat_tbl.Rows[i][nameCol];
                            }
                            else {
                                
                                if (wDef_tbl.Rows[j]["tipo"] == "money")
                                    elm.innerHTML = formato_numero((wDat_tbl.Rows[i][nameCol]), ",", ".", "$");
                                else
                                    if (wDef_tbl.Rows[j]["tipo"] == "text-disabled")
                                        elm.innerHTML = formato_numero((wDat_tbl.Rows[i][nameCol]), ",", ".", "$");
                                    else
                                    elm.innerHTML = wDat_tbl.Rows[i][nameCol];
                            }
                                elm.setAttribute("id", Nom_Tbl + nameCol + "_" + i.toString());
                                elm.setAttribute("class", "renglonTotal");
                        }
                    }
                    elmTD.appendChild(elm);
                    elmTR.appendChild(elmTD);
                } //For definicion de tablas (Columnas)
                obj_ls.appendChild(elmTR);
            } //For Datos
            $('#' + Nom_Tbl).fixedHeaderTable({ altClass: 'odd', footer: false, autoresize: true });
        }
        else {
            alert("Error: No esta definido el esquema de la tabla '" + Nom_Tbl + "'");
        }
    }
    else {
        alert("Error: No se pudo accesar al esquema de la tabla '" + Nom_Tbl + "'");
    }
}

function crear_tabla_reportes(wDat_tbl, Nom_Tbl, NombreMes, NoMes) {
    /// <summary>
    /// Crea una tabla Con el DataTable seleccionado
    /// </summary>
    /// <param name="wDat_tbl">DataTable con los datos de la tabla deseados</param>
    /// <param name="Nom_Tbl">Nombre de la tabla de la que se recuperará el esquema definido en la tabla cfgcols</param>
    var cad_tbl = "";
    resp = SAGEP.Ax_Utilerias.obtener_esquema_tbl(Nom_Tbl);
    wDef_tbl = resp.value;
    if (wDef_tbl != null && wDef_tbl.Rows != null) {
        if (wDef_tbl.Rows.length > 0) {
            cad_tbl = "<table class='tables table-striped table-bordered table-sm' width='100%' style='text-align: center;' id='" + Nom_Tbl + "' cellpadding='0' align='center'> " +
        		              "<thead > <tr> ";
            for (i = 0; i < wDef_tbl.Rows.length; i++) {
                if (wDef_tbl.Rows[i]["visible"] == 1) {
                    if (wDef_tbl.Rows[i]["encab"].toString() == "MES") {
                        cad_tbl = cad_tbl + " <th style = 'width:" + wDef_tbl.Rows[i]["ancho"].toString() + "'>" + NombreMes + "</th>";

                    } else {
                        cad_tbl = cad_tbl + " <th style = 'width:" + wDef_tbl.Rows[i]["ancho"].toString() + "'>" + wDef_tbl.Rows[i]["encab"].toString() + "</th>";

                    }
                }
                else {
                    cad_tbl = cad_tbl + "";
                }

            }
            cad_tbl = cad_tbl + "</tr> </thead>";
            cad_tbl = cad_tbl + "<tbody id='" + Nom_Tbl + "_Det'></tbody></table>";
            document.getElementById("Div_" + Nom_Tbl).innerHTML = cad_tbl;
            document.getElementById("Div_" + Nom_Tbl).setAttribute("title", wDat_tbl.Rows.length);

            obj_ls = document.getElementById(Nom_Tbl + "_Det");
            for (i = 0; i < wDat_tbl.Rows.length; i++) {
                elmTR = document.createElement('tr');
                for (j = 0; j < wDef_tbl.Rows.length; j++) {
                    elmTD = document.createElement('td');
                    elmTD.style.width = wDef_tbl.Rows[j]["ancho"];
                    if (wDef_tbl.Rows[j]["visible"] == 1) {
                        elmTD.style.visibility = "visible";
                        //elmTD.setAttribute("display", "block");
                        //elmTD.attr('style', 'background-color:red')
                    }
                    else {
                        // elmTD.setAttribute("display", "none");
                        elmTD.style.visibility = "hidden";
                    }

                    if (wDef_tbl.Rows[j]["predet"] == "D") elmTD.style.textAlign = "right";

                    switch (wDef_tbl.Rows[j]["tipo"]) {

                        case "span":
                            elm = document.createElement('span');

                            if (wDef_tbl.Rows[j]["columna"].toString() == "rownumber")
                                elm.innerHTML = (i + 1).toString();
                            else
                                elm.innerHTML = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()];

                            elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());

                            break;
                        case "link-rep":
                            if (wDef_tbl.Rows[j]["elep"] != "") {
                                elm = document.createElement('a');
                                elm.setAttribute("class", "span_link");
                                /*if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]] == null)
                                elm.innerHTML = wDef_tbl.Rows[j]["columna"];
                                else*/
                                elm.innerHTML = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]];

                                elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());

                                if (wDef_tbl.Rows[j]["elep"] != "") {
                                    obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                    cad_funcion = obj_json.funcion + " (";
                                    for (h = 0; h < obj_json.parametros.length; h++) {
                                        if (h != 0) cad_funcion = cad_funcion + ",";
                                        if (obj_json.parametros[h].val_parametro.toString() == "0")
                                            cad_funcion = cad_funcion + "'" + j + "'";
                                        else
                                            cad_funcion = cad_funcion + "'" + wDat_tbl.Rows[i][wDef_tbl.Rows[obj_json.parametros[h].val_parametro.toString()]["columna"]] + "'";
                                    }
                                    cad_funcion = cad_funcion + ")";
                                    elm.setAttribute(obj_json.evento, cad_funcion);
                                }
                            }
                            break;
                        case "money":
                            elm = document.createElement('span');

                            if (wDef_tbl.Rows[j]["columna"].toString() == "rownumber")
                                elm.innerHTML = (i + 1).toString();
                            else
                                elm.innerHTML = formato_numero((wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"].toString()]), ",", ".", "$");
                            elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());

                            break;
                        case "link":
                            if (wDef_tbl.Rows[j]["elep"] != "") {
                                elm = document.createElement('a');
                                elm.setAttribute("class", "span_link");
                                if (wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]] == null)
                                    elm.innerHTML = wDef_tbl.Rows[j]["columna"];
                                else
                                    elm.innerHTML = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]];

                                elm.setAttribute("id", Nom_Tbl + wDef_tbl.Rows[j]["columna"] + "_" + i.toString());

                                if (wDef_tbl.Rows[j]["elep"] != "") {
                                    obj_json = JSON.parse(wDef_tbl.Rows[j]["elep"]);
                                    cad_funcion = obj_json.funcion + " (";
                                    for (h = 0; h < obj_json.parametros.length; h++) {
                                        if (h != 0) cad_funcion = cad_funcion + ",";
                                        if (isNaN(obj_json.parametros[h].val_parametro.toString()))
                                            cad_funcion = cad_funcion + "'" + obj_json.parametros[h].val_parametro.toString() + "'";
                                        else
                                            cad_funcion = cad_funcion + "'" + wDat_tbl.Rows[i][wDef_tbl.Rows[obj_json.parametros[h].val_parametro.toString()]["columna"]] + "'";
                                    }
                                    cad_funcion = cad_funcion + ")";
                                    elm.setAttribute(obj_json.evento, cad_funcion);
                                }
                            }
                            break;
                        default:
                            elm = document.createElement('span');
                            elm.innerHTML = wDat_tbl.Rows[i][wDef_tbl.Rows[j]["columna"]];

                            break;
                    }

                    elmTD.appendChild(elm);
                    elmTR.appendChild(elmTD);
                } //For definicion de tablas (Columnas)
                obj_ls.appendChild(elmTR);
            } //For Datos
            $('#' + Nom_Tbl).fixedHeaderTable({ altClass: ' ', footer: false, autoresize: true });
        }
        else {
            alert("Error: No esta definido el esquema de la tabla '" + Nom_Tbl + "'");
        }
    }
    else {
        alert("Error: No se pudo accesar al esquema de la tabla '" + Nom_Tbl + "'");
    }
}

function Inventir_seleccionar_todos(Nom_Tbl) {
    /// <summary>
    /// Seleccionar todos los renglones de una Tabla
    /// </summary>
    /// <param name="Nom_Tbl">Nombre de la tabla a la que pertenecen los Select</param>
    nodos_sel = document.getElementsByName("Sel_" + Nom_Tbl);
    for (i = 0; i < nodos_sel.length; i++)
        nodos_sel[i].checked = false;
}


function seleccionar_todos(Nom_Tbl) {
    /// <summary>
    /// Seleccionar todos los renglones de una Tabla
    /// </summary>
    /// <param name="Nom_Tbl">Nombre de la tabla a la que pertenecen los Select</param>
    nodos_sel = document.getElementsByName("Sel_" + Nom_Tbl);
    for (i = 0; i < nodos_sel.length; i++)
        nodos_sel[i].checked = true;
}

function desseleccionar_todos(Nom_Tbl) {
    /// <summary>
    /// Des-seleccionar todos los renglones de una Tabla
    /// </summary>
    /// <param name="Nom_Tbl">Nombre de la tabla a la que pertenecen los Select</param>
    nodos_sel = document.getElementsByName("SelOpt_" + Nom_Tbl);
    for (i = 0; i < nodos_sel.length; i++)
        nodos_sel[i].checked = false;
}

function invertir_seleccion(Nom_Tbl) {
    /// <summary>
    /// Invierte la selección de la tabla
    /// </summary>
    /// <param name="Nom_Tbl">Nombre de la tabla a la que pertenecen los Select</param>
    nodos_sel = document.getElementsByName("Sel_" + Nom_Tbl);
    for (i = 0; i < nodos_sel.length; i++) {
        if (nodos_sel[i].checked == true)
        { nodos_sel[i].checked = false; }
        else { nodos_sel[i].checked = true; }
    }
}

function recuperar_datos_tabla(Nom_Tbl) { //NO funciona
    /// <summary>
    /// Recupera todos los datos de una tabla
    /// </summary>
    /// <param name="Nom_Tbl">Nombre de la tabla de la que se recuperaran los datos</param>
    /// <returns type="DataTable">Regresa los datos de la tabla en un DataTable o en caso de error regresará null y dará un alert de error</returns>
    var dt = new Ajax.Web.DataTable();
    resp = SAGEP.Ax_Utilerias.obtener_esquema_tbl(Nom_Tbl);
    wDef_tbl = resp.value;
    if (wDef_tbl != null && wDef_tbl.Rows != null) {
        if (wDef_tbl.Rows.length > 0) {
            Dt = formar_tabla_ajax(wDef_tbl);
            num_renglones = document.getElementById("Div_" + Nom_Tbl).title;
            for (i = 0; i < num_renglones.length; i++) {
                num_ctrl = i;
                var row = new Object();

                for (j = 0; j < wDef_tbl.Rows.length; j++) {
                    switch (wDef_tbl.Rows[j]["tipo"]) {
                        case "option":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;                                
                            break;
                        case "checkbox":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                            break;
                        case "checkbox-disabled":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                            break;
                        case "span":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                            break;
                        case "link":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                            break;
                        case "img":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                            break;
                        case "text":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                            break;
                        case "date":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                            break;
                        case "date-mod":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                            break;
                        case "select*":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                            break;
                        default:
                            row[wDef_tbl.Rows[j]["columna"].toString()] = '';
                            break;
                    }
                }
                Dt.addRow(row);
            }
            return Dt;
        }
        else {
            alert("Error: No esta definido el esquema de la tabla '" + Nom_Tbl + "'");
        }
    }
    else {
        alert("Error: No se pudo accesar al esquema de la tabla '" + Nom_Tbl + "'");
    }
}



function recuperar_datos_tabla1(Nom_Tbl) {
     var dt = new Ajax.Web.DataTable();
    resp = SAGEP.Ax_Utilerias.obtener_esquema_tbl(Nom_Tbl);
    wDef_tbl = resp.value;
    if (wDef_tbl != null && wDef_tbl.Rows != null) {
        if (wDef_tbl.Rows.length > 0) {
            Dt = formar_tabla_ajax(wDef_tbl);
            num_renglones = document.getElementById(Nom_Tbl);
            for (i = 0; i < num_renglones.rows.length - 1; i++) {
                num_ctrl = i;
                var row = new Object();

                for (j = 0; j < wDef_tbl.Rows.length; j++) {
                    switch (wDef_tbl.Rows[j]["tipo"]) {
                        case "option":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;                                
                            break;
                        case "checkbox":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = '';// document.getElementById("Sel_Tbl_Ordenes_Operadas_" + (i).toString()).checked; //''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                            break;
                        case "checkboxPlanos":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById("Sel_Tbl_Planos_sitios_" + (i).toString()).checked; //''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                            break;
                        case "checkboxtotal":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML; //document.getElementById("Sel_Tbl_Ordenes_Operadas_" + (i).toString()).checked; //''; //
                            break;
                        case "span":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                            break;
                        case "link":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                            break;
                        case "img":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                            break;
                        case "text":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                            break;
                        case "text-disabled":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                            break;
                        case "select*":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                            break;
                        case "text-vol":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                            break;
                        case "date":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                            break;
                        case "date-mod":
                            hoyFecha();
                            var aux1 = FechaActualFormato.split('-');
                            var aux2 = (document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value).split('-');
                            var f1 = new Date(aux1[0], aux1[1], aux1[2]);
                            var f2 = new Date(aux2[0], aux2[1], aux2[2]);
                            f1.setHours(0, 0, 0, 0);
                            f2.setHours(0, 0, 0, 0);
                            if (f1 > f2) {

                                if (wDef_tbl.Rows[j]["columna"].toString() == "FechaPago" && DiaCerrarPresupuesto != "martes") {
                                    alert("Los Dias de Pago se Realizan los Dias Martes");

                                }
                                alert("DEBES SELECCIONAR UNA FECHA MAYOR O IGUAL A EL DIA DE HOY");
                                return;
                            } else {

                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;

                            }
                            break;
                        case "money":
                            row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML.substr(1).replace(",", "");
                            break;
                        case "date-mod-edit":
                            hoyFecha();
                            var aux1 = FechaActualFormato.split('-');
                            var aux2 = (document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value).split('-');
                            row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                            break;

                        default:
                            row[wDef_tbl.Rows[j]["columna"].toString()] = '';
                            break;
                    }
                }
                Dt.addRow(row);
            }
            return Dt;
        }
        else {
            alert("Error: No esta definido el esquema de la tabla '" + Nom_Tbl + "'");
        }
    }
    else {
        alert("Error: No se pudo accesar al esquema de la tabla '" + Nom_Tbl + "'");
    }
}


function recuperar_datos_tabla_totales(Nom_Tbl) {
    /// <summary>
    /// Recupera todos los datos de una tabla
    /// </summary>
    /// <param name="Nom_Tbl">Nombre de la tabla de la que se recuperaran los datos</param>
    /// <returns type="DataTable">Regresa los datos de la tabla en un DataTable o en caso de error regresará null y dará un alert de error</returns>
    var dt = new Ajax.Web.DataTable();
    resp = SAGEP.Ax_Utilerias.obtener_esquema_tbl(Nom_Tbl);
    wDef_tbl = resp.value;
    if (wDef_tbl != null && wDef_tbl.Rows != null) {
        if (wDef_tbl.Rows.length > 0) {
            Dt = formar_tabla_ajax(wDef_tbl);
            num_renglones = document.getElementById(Nom_Tbl);
            for (i = 0; i < num_renglones.rows.length - 1; i++) {
                num_ctrl = i;
                var row = new Object();
                if (document.getElementById(Nom_Tbl + wDef_tbl.Rows[0]["columna"].toString() + "_" + num_ctrl).innerHTML == "Total") {
                    for (j = 0; j < wDef_tbl.Rows.length; j++) {
                        switch (wDef_tbl.Rows[j]["tipo"]) {
                            case "option":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;                                
                                break;
                            case "checkbox":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = '';// document.getElementById("Sel_Tbl_Ordenes_Operadas_" + (i).toString()).checked; //''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                break;
                            case "checkboxPlanos":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById("Sel_Tbl_Planos_sitios_" + (i).toString()).checked; //''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                break;
                            case "checkboxtotal":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML; //document.getElementById("Sel_Tbl_Ordenes_Operadas_" + (i).toString()).checked; //''; //
                                break;
                            case "span":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = (document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML==""?"":document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML);
                                break;
                            case "link":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                break;
                            case "img":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                break;
                            case "text":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                                break;
                            case "text-disabled":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                                break;
                            case "select*":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                                break;
                            case "text-vol":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                                break;
                            case "date":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                                break;
                            case "date-mod":
                                hoyFecha();
                                var aux1 = FechaActualFormato.split('-');
                                var aux2 = (document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value).split('-');
                                var f1 = new Date(aux1[0], aux1[1], aux1[2]);
                                var f2 = new Date(aux2[0], aux2[1], aux2[2]);
                                f1.setHours(0, 0, 0, 0);
                                f2.setHours(0, 0, 0, 0);
                                if (f1 > f2) {

                                    if (wDef_tbl.Rows[j]["columna"].toString() == "FechaPago" && DiaCerrarPresupuesto != "martes") {
                                        alert("Los Dias de Pago se Realizan los Dias Martes");

                                    }
                                    alert("DEBES SELECCIONAR UNA FECHA MAYOR O IGUAL A EL DIA DE HOY");
                                    return;
                                } else {

                                    row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;

                                }
                                break;
                            case "money":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML.substr(1).replace(",", "");
                                break;
                            case "date-mod-edit":
                                hoyFecha();
                                var aux1 = FechaActualFormato.split('-');
                                var aux2 = (document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value).split('-');
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                                break;

                            default:
                                row[wDef_tbl.Rows[j]["columna"].toString()] = '';
                                break;
                        }
                    }
                    Dt.addRow(row);
                }
            }
            return Dt;
        }
        else {
            alert("Error: No esta definido el esquema de la tabla '" + Nom_Tbl + "'");
        }
    }
    else {
        alert("Error: No se pudo accesar al esquema de la tabla '" + Nom_Tbl + "'");
    }
}

function hoyFecha() {
    var dias = ["domingo", "lunes", "martes", "miercoles", "jueves", "viernes", "sabado"];
    var hoy = new Date();
    var dd = hoy.getDate();
    var mm = hoy.getMonth() + 1; //hoy es 0!
    var yyyy = hoy.getFullYear();

    if (dd < 10) {
        dd = '0' + dd
    }

    if (mm < 10) {
        mm = '0' + mm
    }

    hoy = yyyy + '-' + mm + '-' + dd;
    FechaActualFormato = hoy;

    var dt = new Date(mm + ' ' + dd + ', ' + yyyy + ' 12:00:00');
    DiaCerrarPresupuesto = dias[dt.getUTCDay()];

}

function recuperar_opc_sel(Nom_Tbl) { //no funciona
    /// <summary>
    /// Recupera las opciones seleccionadas
    /// </summary>
    /// <param name="Nom_Tbl">Nombre de la tabla de la que se recuperaran los datos</param>
    /// <returns type="DataTable">Regresa los datos de la tabla en un DataTable o en caso de error regresará null y dará un alert de error</returns>
    var Dt = new Ajax.Web.DataTable();
    resp = SAGEP.Ax_Utilerias.obtener_esquema_tbl(Nom_Tbl);
    wDef_tbl = resp.value;
    if (wDef_tbl != null && wDef_tbl.Rows != null) {
        if (wDef_tbl.Rows.length > 0) {
            Dt = formar_tabla_ajax(wDef_tbl);
            nodos_sel = document.getElementsByName("SelOpt_" + Nom_Tbl);
            for (i = 0; i < nodos_sel.length; i++) {
                if (nodos_sel[i].checked == true) {
                    var pos = nodos_sel[i].id.lastIndexOf("_");
                    var num_ctrl = nodos_sel[i].id.substring(pos + 1);
                    var row = new Object();
                    for (j = 0; j < wDef_tbl.Rows.length; j++) {

                        switch (wDef_tbl.Rows[j]["tipo"]) {
                            case "option":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;                                
                                break;
                            case "checkbox":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                break;
                            case "span":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                break;
                            case "link":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                break;
                            case "img":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                break;
                            case "select*":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                                break;
                            default:
                                row[wDef_tbl.Rows[j]["columna"].toString()] = '';
                                break;
                        }
                    }
                    Dt.addRow(row);
                }
            }
            return Dt;
        }
        else {
            alert("Error: No esta definido el esquema de la tabla '" + Nom_Tbl + "'");
        }
    }
    else {
        alert("Error: No se pudo accesar al esquema de la tabla '" + Nom_Tbl + "'");
    }
}


function recuperar_seleccion(Nom_Tbl) {
    /// <summary>
    /// Recupera la seleccion de una tabla
    /// </summary>
    /// <param name="Nom_Tbl">Nombre de la tabla</param>
    /// <returns type="DataTable">Regresa los datos de la tabla en un DataTable o en caso de error regresará null y dará un alert de error</returns>
    var Dt = new Ajax.Web.DataTable();
    resp = SAGEP.Ax_Utilerias.obtener_esquema_tbl(Nom_Tbl);
    wDef_tbl = resp.value;
    if (wDef_tbl != null && wDef_tbl.Rows != null) {
        if (wDef_tbl.Rows.length > 0) {
            Dt = formar_tabla_ajax(wDef_tbl);
            nodos_sel = document.getElementsByName("Sel_" + Nom_Tbl);
            for (i = 0; i < nodos_sel.length; i++) {
                if (nodos_sel[i].checked == true) {
                    var pos = nodos_sel[i].id.lastIndexOf("_");
                    var num_ctrl = nodos_sel[i].id.substring(pos + 1);
                    var row = new Object();
                    for (j = 0; j < wDef_tbl.Rows.length; j++) {
                        switch (wDef_tbl.Rows[j]["tipo"]) {
                            case "option":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;                                
                                break;
                            case "checkbox":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                break;
                            case "span":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                break;
                            case "link":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                break;
                            case "text":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                                break;
                            case "text-disabled":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                                break;
                            case "img":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                break;
                            case "date":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = cambiar_formato_fecha(document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML);
                                break;
                            case "money":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML.substr(1).replace(",", "");
                                break;
                            case "select*":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                                break;
                            default:
                                row[wDef_tbl.Rows[j]["columna"].toString()] = '';
                                break;
                        }
                    }
                    Dt.addRow(row);
                }
            }
            return Dt;

        }
        else {
            alert("Error: No esta definido el esquema de la tabla '" + Nom_Tbl + "'");
        }
    }
    else {
        alert("Error: No se pudo accesar al esquema de la tabla '" + Nom_Tbl + "'");
    }
}


function recuperar_seleccion_totales(Nom_Tbl) {
    /// <summary>
    /// Recupera la seleccion de una tabla
    /// </summary>
    /// <param name="Nom_Tbl">Nombre de la tabla</param>
    /// <returns type="DataTable">Regresa los datos de la tabla en un DataTable o en caso de error regresará null y dará un alert de error</returns>
    var Dt = new Ajax.Web.DataTable();
    resp = SAGEP.Ax_Utilerias.obtener_esquema_tbl(Nom_Tbl);
    wDef_tbl = resp.value;
    if (wDef_tbl != null && wDef_tbl.Rows != null) {
        if (wDef_tbl.Rows.length > 0) {
            Dt = formar_tabla_ajax(wDef_tbl);
            nodos_sel = document.getElementsByName("Sel_" + Nom_Tbl);
            for (i = 0; i < nodos_sel.length; i++) {
                if (nodos_sel[i].checked == true) {
                    var pos = nodos_sel[i].id.lastIndexOf("_");
                    var num_ctrl = nodos_sel[i].id.substring(pos + 1);
                    var row = new Object();
                    if (document.getElementById(Nom_Tbl + wDef_tbl.Rows[0]["columna"].toString() + "_" + num_ctrl).innerHTML == "Total") {
                        for (j = 0; j < wDef_tbl.Rows.length; j++) {
                            switch (wDef_tbl.Rows[j]["tipo"]) {
                                case "option":
                                    row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;                                
                                    break;
                                case "checkbox":
                                    row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                    break;
                                case "span":
                                    row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                    break;
                                case "link":
                                    row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                    break;
                                case "text":
                                    row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                                    break;
                                case "text-disabled":
                                    row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                                    break;
                                case "img":
                                    row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                    break;
                                case "date":
                                    row[wDef_tbl.Rows[j]["columna"].toString()] = cambiar_formato_fecha(document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML);
                                    break;
                                case "money":
                                    row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML.substr(1).replace(",", "");
                                    break;
                                case "select*":
                                    row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                                    break;
                                default:
                                    row[wDef_tbl.Rows[j]["columna"].toString()] = '';
                                    break;
                            }
                        }
                        Dt.addRow(row);
                    }
                }
            }
            return Dt;

        }
        else {
            alert("Error: No esta definido el esquema de la tabla '" + Nom_Tbl + "'");
        }
    }
    else {
        alert("Error: No se pudo accesar al esquema de la tabla '" + Nom_Tbl + "'");
    }
}

function recuperar_no_seleccion(Nom_Tbl) {
    /// <summary>
    /// Recupera la seleccion de una tabla
    /// </summary>
    /// <param name="Nom_Tbl">Nombre de la tabla</param>
    /// <returns type="DataTable">Regresa los datos de la tabla en un DataTable o en caso de error regresará null y dará un alert de error</returns>
    var Dt = new Ajax.Web.DataTable();
    resp = SAGEP.Ax_Utilerias.obtener_esquema_tbl(Nom_Tbl);
    wDef_tbl = resp.value;
    if (wDef_tbl != null && wDef_tbl.Rows != null) {
        if (wDef_tbl.Rows.length > 0) {
            Dt = formar_tabla_ajax(wDef_tbl);
            nodos_sel = document.getElementsByName("Sel_" + Nom_Tbl);
            for (i = 0; i < nodos_sel.length; i++) {
                if (nodos_sel[i].checked == false) {
                    var pos = nodos_sel[i].id.lastIndexOf("_");
                    var num_ctrl = nodos_sel[i].id.substring(pos + 1);
                    var row = new Object();
                    for (j = 0; j < wDef_tbl.Rows.length; j++) {
                        switch (wDef_tbl.Rows[j]["tipo"]) {
                            case "option":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;                                
                                break;
                            case "checkbox":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                break;
                            case "span":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                break;
                            case "link":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                break;
                            case "text":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                                break;
                            case "img":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = ''; //document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML;
                                break;
                            case "money":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML.substr(1).replace(",", "");
                                break;
                            case "date":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = cambiar_formato_fecha(document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).innerHTML);
                                break;
                            case "select*":
                                row[wDef_tbl.Rows[j]["columna"].toString()] = document.getElementById(Nom_Tbl + wDef_tbl.Rows[j]["columna"].toString() + "_" + num_ctrl).value;
                                break;
                            default:
                                row[wDef_tbl.Rows[j]["columna"].toString()] = '';
                                break;
                        }
                    }
                    Dt.addRow(row);
                }
            }
            return Dt;

        }
        else {
            alert("Error: No esta definido el esquema de la tabla '" + Nom_Tbl + "'");
        }
    }
    else {
        alert("Error: No se pudo accesar al esquema de la tabla '" + Nom_Tbl + "'");
    }
}

function formar_tabla_ajax(wDef_tbl) {
    /// <summary>
    /// Dar Formato de ajax a una tabla
    /// </summary>
    /// <param name="wDef_tbl">Tabla a la que se le dará formato</param>
    /// <returns type="DataTable">Regresa los datos de la tabla en un DataTable</returns>
    var dt = new Ajax.Web.DataTable();
    for (i = 0; i < wDef_tbl.Rows.length; i++) {
        dt.addColumn(wDef_tbl.Rows[i]["columna"].toString(), "System.String");
    }
    return dt;
}
/*************************FIN TABLA****************************************/

/**************FUNCIONES DE CATALOGOS*********************************/
function crear_listado_cat(wnom_cat) {
    /// <summary>
    /// 
    /// </summary>
    /// <param name="wnom_cat"></param>

    //Menu Cat
    $("#Div_Cont_Cat").append('<div class = "submenu" ><table ><tr>' +
                                  '<td class ="ui-corner-all submenu_td" onclick="quitar_registro();" title = "Presione para quitar un registro de la relación"  > ' +
                                  '<img alt="Quitar registro" src="Images/Quitar_reg.png"/>Quitar Reg. ' +
                                  '</td> ' +
                                  '<td class ="ui-corner-all submenu_td " onclick="agregar_registro();" title = "Presione para agregar un registro a la relación"> ' +
                                  '<img alt="Agregar registro" src="Images/Agregar_reg.png"/> Agregar Reg. ' +
                                  '</td> ' +
                                  '</tr></table></div> ');

    //Crear contenedor y tabla
    $("#Div_Cont").append('<div class="ui-widget-content ui-corner-all div_dialog">  <h3  class="ui-widget-header ui-corner-all">Listado de movimientos</h3> <div id = "Div_Tbl_Rels_Rech" style = "height: 280px; width: 100%; overflow-x: auto;overflow-y: auto;"> </div> </div>');
    //llenar listado
    var dt = new Ajax.Web.DataTable();
    dt.addColumn("fecha", "System.String");
    dt.addColumn("relacion", "System.String");
    dt.addColumn("usuario", "System.String");

    var row = new Object();
    row["fecha"] = "03/Marzo/2015";
    row["relacion"] = "20160005";
    row["usuario"] = "Hector";
    dt.addRow(row);
    crear_tabla(dt, "Tbl_Rels_Rech");

}
/***************************FIN FUNCIONES DE CATALOGOS *************************************/

function obtener_modulos() {
    /// <summary>
    /// Obtiene el listado de los Módulos a los que tiene acceso el usuario
    /// </summary>
    lbl = document.getElementById("lbl_user").innerHTML;
    SAGEP.AxAccesoS.obtener_modulos(lbl, mostrar_modulos);
}

function mostrar_modulos(resp) {
    /// <summary>
    /// Muestra los módulos a los que tiene acceso el usuario
    /// </summary>
    /// <param name="resp">Recibe el listado de los modulos</param>
    modulos = resp.value;
    if (modulos != null && typeof (modulos) == "object" && modulos.Rows != null) {
        for (i = 0; i <= modulos.Rows.length - 1; i++) {
            switch (modulos.Rows[i].drive.toString()) {
                case "M":
                    $("#metrobuttonsM").AddMetroSimpleButton('bt' + modulos.Rows[i].clave_mod.toString(), 'metro-laranja', 'Images/Modulos/' + modulos.Rows[i].icono, modulos.Rows[i].nombre, 'window.location="' + modulos.Rows[i].ruta + '";');
                    break;
                case "R":
                    $("#metrobuttonsR").AddMetroSimpleButton('bt' + modulos.Rows[i].clave_mod.toString(), 'metro-roxo', 'Images/Modulos/' + modulos.Rows[i].icono, modulos.Rows[i].nombre, 'window.location="' + modulos.Rows[i].ruta + '";');
                    break;
                case "C":
                    $("#metrobuttonsC").AddMetroSimpleButton('bt' + modulos.Rows[i].clave_mod.toString(), 'metro-azul', 'Images/Modulos/' + modulos.Rows[i].icono, modulos.Rows[i].nombre, 'window.location="' + modulos.Rows[i].ruta + '";');
                    break;
            }
        }
    }
    else {
        //alert("¡ Tu sesión de trabajo a finalizado, identificate nuevamente !");
        location.href = "Login.aspx";
    }
}

//*****MANEJO DE LISTAS
function CreoDivConGen(otxt, otxt2, oLong) {
    /// <summary>
    /// Crea Div Para la busqueda de texto predictivo
    /// </summary>
    /// <param name="otxt">Texto padre</param>
    /// <param name="otxt2">No utilizado</param>
    /// <param name="oLong">No utilizado</param>
    var oPadre = document.getElementById(otxt).parentNode;
    var oElemento = document.getElementById(otxt);
    EliminoDiv(oPadre, "Div_con_gen");

    controlDin = document.createElement('div');
    controlDin.id = 'Div_con_gen';
    controlDin.innerHTML = "<select id = 'ls_gen' style = 'width:100%; height:100%' size = '3'  ondblclick='poner_gen();'  onkeydown = 'poner_gen(event);'></select>";
    //controlDin.className = 'ClaseDiv';
    controlDin.onkeydown = function () { inhabilitar_key(event); }
    //hgmncontrolDin.onkeyup = function () { buscar_gen(event, otxt, otxt2, "",oLong); }
    controlDin.style = "height:150px; width: " + $("#" + otxt).width() + "px; overflow-x: auto;overflow-y: auto; position:absolute; top: " + oElemento.style.top + "px; left: " + oElemento.style.left + "px; z-index:3; display:none";
    //controlDin.style = "height:150px; width: " + oElemento.style.width + "; overflow-x: auto;overflow-y: auto; position:absolute; top: " + oElemento.style.top + "px; left: " + oElemento.style.left + "px; z-index:3; display:none";
    oPadre.appendChild(controlDin);
}

function EliminoDiv(padre, objeto) {
    /// <summary>
    /// Elimina el Div para la busqueda de texto predictivo
    /// </summary>
    /// <param name="padre">Objeto padre de el div a eliminar</param>
    /// <param name="objeto">Objeto a eliminar</param>

    // var ContenedorObjeto = document.getElementById(padre);
    var ContenedorObjeto = padre;
    try {
        ContenedorObjeto.removeChild(document.getElementById(objeto));
        //alert(padre.id);
    }
    catch (e) {
        //alert(e.Message);
    }
}

var objetoPoner = "";
var objetoPoner2 = "";

function inhabilitar_key(e) {
    /// <summary>
    /// Inhabilitar tecla
    /// </summary>
    /// <param name="e">Código de la tecla</param>
    if (e.keyCode == 38 || e.keyCode == 40) {
        e.returnValue = false;
    }
}


function buscar_gen(e, otxt, otxt2, oQry, oLong) {
    /// <summary>
    /// Busca el texto en la tabla especificada para una busqueda de texto predictiva
    /// </summary>
    /// <param name="e">Tecla presionada</param>
    /// <param name="otxt">Cadena de texto escrito</param>
    /// <param name="otxt2">Cadena de texto seleccionado</param>
    /// <param name="oQry">Especificación de la tabla o tipo de busqueda que se hará</param>
    /// <param name="oLong">Longitud minima para empezar a buscar</param>
    objetoPoner = otxt;
    objetoPoner2 = otxt2;
    document.getElementById(otxt).title = "";
    if (otxt2 != "") document.getElementById(otxt2).value = "";
    obj_sel = document.getElementById("ls_gen");
    switch (e.keyCode) {
        case 27:
            //Esc                    
            objetoPadre = document.getElementById(otxt).parentNode;
            EliminoDiv(objetoPadre, "Div_con_gen");
            break;
        case 13:
            //enter
            if (obj_sel.selectedIndex >= 0) {
                document.getElementById(otxt).value = obj_sel.options[obj_sel.selectedIndex].text;
                document.getElementById(otxt).title = obj_sel.options[obj_sel.selectedIndex].value;
                if (objetoPoner2 != "") {
                    document.getElementById(objetoPoner2).value = obj_sel.options[obj_sel.selectedIndex].value;
                }
                objetoPadre = document.getElementById(otxt).parentNode;
                EliminoDiv(objetoPadre, "Div_con_gen");
            }
            break;
        case 38:
            //up
            if (obj_sel.options.length > 0) {
                if (obj_sel.selectedIndex > 0)
                { obj_sel.selectedIndex = obj_sel.selectedIndex - 1; }
            }
            break;
        case 40:
            //down
            if (obj_sel.options.length > 0) {
                if (obj_sel.selectedIndex < obj_sel.options.length - 1)
                { obj_sel.selectedIndex = obj_sel.selectedIndex + 1; }
            }
            break;
        default:
            if ((e.keyCode == 8) || (e.keyCode >= 65 && e.keyCode <= 90) || (e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105)) {
                limpiar_tabla("ls_gen");

                var nombre = document.getElementById(otxt).value;
                if (nombre.length >= oLong) {

                    CreoDivConGen(otxt, otxt2, oLong);
                    objetoPadre = document.getElementById(otxt).parentNode.id;
                    obj_sel = document.getElementById("ls_gen");

                    switch (oQry) {
                        case "con_empleados_por_nombre":
                            resp = SAGEP.Ax_Empleados.buscar_empleado("", "", "", "", "", "", nombre, "", "", "");
                            wdt = resp.value;
                            llenar_ls("ls_gen", wdt, "NomEmp", "IdEmpleado", "");
                            break;
                        case "con_empleados_activos_por_nombre":
                            resp = SAGEP.Ax_Empleados.buscar_empleado("", "", "", "", "", "", nombre, "", "1", "");
                            wdt = resp.value;
                            llenar_ls("ls_gen", wdt, "NomEmp", "IdEmpleado", "");
                            break;
                        case "con_sitio_por_clave":
                            resp = SAGEP.Ax_Catalogo.buscar_sitios("", nombre, "");
                            wdt = resp.value;
                            llenar_ls("ls_gen", wdt, "Clave", "IdSitio", "");
                            break;
                        case "con_articulo_por_descripcion":
                            resp = SAGEP.Ax_Catalogo.buscar_articulos("", "", nombre);
                            wdt = resp.value;
                            llenar_ls("ls_gen", wdt, "Descripcion", "IdArticulo", "");
                            break;
                        case "con_Contacto_por_nombre":
                            resp = SAGEP.Ax_Contacto.buscar_Contacto("", nombre, "");
                            wdt = resp.value;
                            llenar_ls("ls_gen", wdt, "NombreComercial", "IdProveedor", "");
                            break;
                        case "con_almacen_por_encargado":
                            resp = SAGEP.Ax_Catalogo.buscar_almacenes("", nombre, "");
                            wdt = resp.value;
                            llenar_ls("ls_gen", wdt, "Encargado", "IdAlmacen", "");
                            break;
                        case "con_empleados_por_nombre_encargado":
                            resp = SAGEP.Ax_Empleados.buscar_empleado("", "", "", "", "", "", nombre, "", "", "");
                            wdt = resp.value;
                            llenar_ls("ls_gen", wdt, "NomEmp", "IdEmpleado", "");
                            break;

                        default:
                            break;
                    }
                    if (obj_sel.childNodes.length > 0)
                    { document.getElementById("Div_con_gen").style.display = "block"; }
                }
            }
            break;
    }
}

function poner_gen(e) {
    /// <summary>
    /// Pone el elemento seleccionado en el div o input de busqueda
    /// </summary>
    /// <param name="e">Texto Buscado en caso de ser nulo pone el elemento seleccionado con el clic</param>
    obj_sel = document.getElementById("ls_gen");
    objetoPadre = document.getElementById(objetoPoner).parentNode;
    if (e == null) {
        if (obj_sel.selectedIndex >= 0) {
            document.getElementById(objetoPoner).value = obj_sel.options[obj_sel.selectedIndex].text;
            document.getElementById(objetoPoner).title = obj_sel.options[obj_sel.selectedIndex].value;
            if (objetoPoner2 != "") {
                document.getElementById(objetoPoner2).value = obj_sel.options[obj_sel.selectedIndex].value;
            }
            EliminoDiv(objetoPadre, "Div_con_gen");
            document.getElementById(objetoPoner).focus();
        }
    }
    else {
        if (e.keyCode == 13) {
            if (obj_sel.selectedIndex >= 0) {
                document.getElementById(objetoPoner).value = obj_sel.options[obj_sel.selectedIndex].text;
                document.getElementById(objetoPoner).title = obj_sel.options[obj_sel.selectedIndex].value;
                if (objetoPoner2 != "") {
                    document.getElementById(objetoPoner2).value = obj_sel.options[obj_sel.selectedIndex].value;
                }
                EliminoDiv(objetoPadre, "Div_con_gen");
                //buscar_movimientos();
            }
        }
    }
    objetoPoner = "";
}


function buscar_proyectos(wControl) {
    /// <summary>
    /// Llena un control con los nombres de los proyectos seleccionados
    /// </summary>
    /// <param name="wControl">Nombre o id del control</param>
    limpiar_tabla(wControl);
    resp = SAGEP.Ax_Proyectos.buscar_proyectos("");
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wControl, wdt, "Nombre", "IdProyecto", "");
    }

}

function buscar_work_orders(wControl) {
    /// <summary>
    /// Llena un control con los nombres de las claves de las work orders
    /// </summary>
    /// <param name="wControl">Nombre o id del control</param>
    limpiar_tabla(wControl);
    resp = SAGEP.Ax_Work_Orders.buscar_work_orders("", "");
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wControl, wdt, "Clave_Descripcion", "IdWorkOrder", "");
    }
}

function buscar_Familia(wControl) {
    /// <summary>
    /// Lllena un control con el listado de las familias
    /// </summary>
    /// <param name="wControl">Nombre o id del control</param>
    resp = SAGEP.Ax_Catalogo.buscar_Familia("", "");
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wControl, wdt, "NombreFamilia", "IdFamilia", "");
    }
}


function buscar_FamiliaXTipo(wControl, wTipo) {
    /// <summary>
    /// Lllena un control con el listado de las familias
    /// </summary>
    /// <param name="wControl">Nombre o id del control</param>
    resp = SAGEP.Ax_Catalogo.buscar_FamiliaxTipo("", "", wTipo);
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wControl, wdt, "Nombre", "IdFamilia", "");
    }
}


function buscar_familiaxTT(wControl) {
    /// <summary>
    /// Lllena un control con el listado de las familias
    /// </summary>
    /// <param name="wControl">Nombre o id del control</param>
    resp = SAGEP.Ax_Cliente.buscar_familias_por_tt("");
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wControl, wdt, "NomFam", "IdFamiliaxTT", "");
    }
}


function buscar_CuentasMayor(wControl) {
    /// <summary>
    /// Lllena un control con el listado de las familias
    /// </summary>
    /// <param name="wControl">Nombre o id del control</param>
    resp = SAGEP.Ax_Catalogo.buscarCuentasMayor("");
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wControl, wdt, "CuentaMayor", "IdCuentaMayor", "");
    }
}


function buscar_CuentasMenor(wControl) {
    /// <summary>
    /// Lllena un control con el listado de las familias
    /// </summary>
    /// <param name="wControl">Nombre o id del control</param>
    resp = SAGEP.Ax_Catalogo.buscarCuentasMenor("");
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wControl, wdt, "CuentaContable", "IdCuentaMenor", "");
    }
}


function buscar_CuentasPropias(wControl) {
    /// <summary>
    /// Lllena un control con el listado de las familias
    /// </summary>
    /// <param name="wControl">Nombre o id del control</param>
    resp = SAGEP.Ax_Catalogo.buscarCuentasPropias("");
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wControl, wdt, "NombreCuenta", "IdCuenta", "");
    }
}

function buscar_SubfamiliaDepreciacion(wControl) {
    /// <summary>
    /// Lllena un control con el listado de las familias
    /// </summary>
    /// <param name="wControl">Nombre o id del control</param>
    resp = SAGEP.Ax_Catalogo.buscar_SubfamiliaDepreciacion("");
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wControl, wdt, "NombreSubfamiliaTT", "IdSubfamiliaxTT", "");
    }
}


function buscar_Almacenes(wControl) {
    /// <summary>
    /// Lllena un control con el listado de las familias
    /// </summary>
    /// <param name="wControl">Nombre o id del control</param>
    resp = SAGEP.Ax_Almacenes.buscar_Almacenes("");
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wControl, wdt, "NombreAlmacen", "IdAlmacen", "");
    }
}


function buscar_OrdenesCompra(wControl) {
    /// <summary>
    /// Lllena un control con el listado de las familias
    /// </summary>
    /// <param name="wControl">Nombre o id del control</param>
    resp = SAGEP.Ax_OrdenCompra.buscarOrdenesCompra("");
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wControl, wdt, "NombreOrdenCompra", "IdOrdenCompra", "");
    }
}


function buscar_Clientes(wControl) {
    resp = SAGEP.Ax_Catalogo.buscar_Clientes("", "");
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wControl, wdt, "NombreCliente", "IdCliente", "");
    }
}
function buscar_Subfamilias(wControl, wIdFamilia) {
    /// <summary>
    /// Lllena un control con el listado de las familias
    /// </summary>
    /// <param name="wControl">Nombre o id del control</param>
    resp = SAGEP.Ax_Catalogo.buscar_SubFamilia(wIdFamilia);
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wControl, wdt, "NombreSubfamilia", "IdSubFamilias", "");
    }
}

function llenaContacto(wselect) {
    resp = SAGEP.Ax_Contacto.buscar_Contacto("", "", "");
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wselect, wdt, "NombreComercial", "IdProveedor", "");
    }
}

function llenaPresupuestos(wselect) {
    resp = SAGEP.Ax_OrdenCompra.buscar_presupuesto("", "");
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wselect, wdt, "NombrePresupuesto", "IdPresupuesto", "");
    }
}

function llenaOrdenDispersion(wselect) {
    resp = SAGEP.Ax_OrdenCompra.buscar_orden_dispersion("", "");
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wselect, wdt, "NombreOrdenDispersion", "IdOrdenDispersion", "");
    }
}


function buscar_CentroCosto(wControl) {
    /// <summary>
    /// Llena un listado con el nombre de los centros de costos
    /// </summary>
    /// <param name="wControl">Nombre o id del control</param>
    limpiar_tabla(wControl);
    resp = SAGEP.Ax_Catalogo.buscar_CentroCosto("", "");
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wControl, wdt, "Nombre", "IdCentroCosto", "");
    }
}

function buscar_sitios(wControl) {
    /// <summary>
    /// Llena un listado con el nombre de los sitios
    /// </summary>
    /// <param name="wControl">Nombre o id del control</param>
    limpiar_tabla(wControl);
    resp = SAGEP.Ax_Catalogo.buscar_sitios("", "", "");
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        llenar_ls(wControl, wdt, "NombreSitio", "Id_Sitios", "");
    }

}

function cambiar_formato_fecha(fecha) {

    if (fecha != "") {
        arrFecha = fecha.split("-");
        for (z = 0; z < arrMeses.length; z++) {
            if (arrMeses[z] == arrFecha[1])
                break;
        }
        if (z < 10)
            fecha = arrFecha[0] + "-0" + z + "-" + arrFecha[2];
        else
            fecha = arrFecha[0] + "-" + z + "-" + arrFecha[2];
    }
    return fecha;
}

function buscar_check_catalogo(wDominio, wIdCatalogoP, wControl, wColTam, wFuncion,wCheckedDefault) {

    resp = SAGEP.Ax_Catalogo.buscar_elementos_catalogo(wDominio, wIdCatalogoP);
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        for (i = 0; i < wdt.Rows.length; i++) {
            lista = document.getElementById(wControl);
            var elmDiv = document.createElement("div");
            elmDiv.setAttribute("class", "form-group col-md-" + wColTam);
            var elmL = document.createElement('label');
            elmL.innerHTML = wdt.Rows[i]["Catalogo"].toString() + " ";
            var elm = document.createElement('input');
            elm.setAttribute("id", "ck_" + wdt.Rows[i]["Dominio"].toString() + "_" + i.toString());
            elm.setAttribute("name", wControl);
            elm.setAttribute("type", "checkbox");
            elm.checked = wCheckedDefault;
            elm.setAttribute("value", wdt.Rows[i]["IdCatalogo"].toString());
            if (wFuncion != "")
                elm.setAttribute("onchange", wFuncion);
            elmL.appendChild(elm);
            elmDiv.appendChild(elmL);
            lista.appendChild(elmDiv);
        }
    }
    else {
        alert("Error: No fue posible consultar el catalogo '" + wDominio + "'");
        return;
    }
}

function crear_check_dinamicos(wDt, wControl, wColTam, wFuncion, wCheckedDefault, wCampo, wValor, wGrupo) {
    if (wDt != null && wDt.Rows != null) {
        for (i = 0; i < wDt.Rows.length; i++) {
            lista = document.getElementById(wControl);
            var elmDiv = document.createElement("div");
            elmDiv.setAttribute("class", "form-group col-md-" + wColTam);
            var elmL = document.createElement('label');
            elmL.setAttribute("id", "lbl_" + wGrupo + "_" + i.toString());
            elmL.innerHTML = wDt.Rows[i][wCampo].toString() + " ";
            var elm = document.createElement('input');
            elm.setAttribute("id", "ck_" + wGrupo + "_" + i.toString());
            elm.setAttribute("name",  wGrupo );
            elm.setAttribute("type", "checkbox");
            elm.checked = wCheckedDefault;
            elm.setAttribute("value", wDt.Rows[i][wValor].toString());
            if (wFuncion != "")
                elm.setAttribute("onchange", wFuncion);
            elmL.appendChild(elm);
            elmDiv.appendChild(elmL);
            lista.appendChild(elmDiv);
        }
    }
}