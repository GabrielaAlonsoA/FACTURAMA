﻿
window.onload = funcInicio;

function funcInicio() {
    /// <summary>
    /// Pone focus en el campo del nombre del usuario por default
    /// </summary>
    $("#usrio").focus();
    return;
}

function InicioSesion() {
    /// <summary>
    /// Verifica el nombre de usuario y contraseña y llama a la consulta de los datos en la base de datos
    /// </summary>
    var divM = "#DivMulti";
    var Nombre = $("#usrio").val();
    var Password = $("#pswd").val();
    $(divM).html("");
    if (Nombre == "") { $(divM).html("No ha especificado su nombre de usuario"); $("#usrio").focus(); return; } Nombre = OsmosisP(Nombre);
    if (Password == "") { $(divM).html("No ha especificado su contraseña"); $("#pswd").focus(); return; } Password = OsmosisP(Password);
    divEspere(1, 'Body');
    SAGEP.AxAccesoS.PermitoAcceso(Nombre, Password, respInicioSesion);

}

function respInicioSesion(res) {
    /// <summary>
    /// Verifica si puede iniciar sessión, si no arroja alertas con mensaje de error
    /// </summary>
    /// <param name="res">Resultados de la consulta del inicio de sesión</param>
    var divM = "#DivMulti";
    $(divM).html("");
    try {
        var resultado = res.value;
        var n = -1;
        n = resultado.indexOf("Acceso no autorizado");
        if (n >= 0) {
            //$(divM1).html(resultado);
            alert(resultado);
            eliminoDivEspere();
        }
        else {
            window.location.replace(resultado);
        }
    } catch (e) {
        alert("Por el momento no es posible ingresar");
        eliminoDivEspere();
    }
}

function RecuperoPsUs() {
    /// <summary>
    /// Recupera el Pasword de el usuario
    /// </summary>
    var divM = "#DivMulti";
    var Usuario = $("#usuarioRec").val();

    $(divM).html("");
    if (Usuario == "") { $(divM).html("No ha especificado su nombre de usuario"); return; } Usuario = OsmosisP(Usuario);

    divEspere(1, 'Body');
    SAGEP.AxAccesoS.RecuperaPs(Usuario, respRecuperoPsUs);
}

function respRecuperoPsUs(res) {
    /// <summary>
    /// Regresa la respuesta de la recuperación de contraseña
    /// </summary>
    /// <param name="res">Respuesta de la consulta de contraseña</param>
    var divM = "#DivMulti";
    $(divM).html("");
    try {
        var resultado = res.value;
        $(divM).html(resultado);
    } catch (e) {
        alert("por el momento no esta disponible la recuperación");
    }
    eliminoDivEspere();
}

function divEspere(imagen, divBloquear) {
    /// <summary>
    /// Muestra el div de espera
    /// </summary>
    /// <param name="imagen">Imagen de espera</param>
    /// <param name="divBloquear">Nombre del div que bloqueará la pantalla</param>
    eliminoDivEspere();
    if (divBloquear == 'Body') {
        var bodyElemento = document.getElementsByTagName('Body');
        var divB = bodyElemento[0];
    } else {
        divB = document.getElementById(divBloquear);
    }
    DivBloqueo = document.createElement('div');
    DivBloqueo.className = "divPrecarga"
    DivBloqueo.id = "espere" + imagen;
    divB.appendChild(DivBloqueo);
}

function eliminoDivEspere() {
    /// <summary>
    /// Elimina div de espera
    /// </summary>
    $(".divPrecarga").remove();
}

function MuestroDivRecuperar() {
    /// <summary>
    /// Muesta el div con los campos para recuperar contraseña
    /// </summary>
    var divM = "#DivMulti";
    $(divM).html("");
    $(divM).html("<p>Escribe tu usuario y presiona recuperar</p><input type='text' required id='usuarioRec' value = '" + $("#usrio").val() + "' placeholder='Usuario a recuperar'/><input type='button' value='Cancelar' onclick='canceloRecuperar()'/><input type='button' value='Recuperar' onclick='RecuperoPsUs()'/>");
}

function canceloRecuperar() {
    /// <summary>
    /// Cancela la Recuperación de contraseña
    /// </summary>
    var divM = "#DivMulti";
    $(divM).html("");
}

function OsmosisP(Parametro) {
    /// <summary>
    /// Cambia comilla simple por doble comilla para poder insertar comilla simple en la base de datos
    /// </summary>
    /// <param name="Parametro">Cadena que se cambiará para poder insertar comilla simple en la base de datos</param>
    /// <returns type=""></returns>
    Parametro = Parametro.replace("'", "''");
    return Parametro;
}