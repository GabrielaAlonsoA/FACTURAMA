﻿

function mostrar_dialog_busqueda_empleado() {

    var cad = "<table ><tr>";
    cad += "<td style ='width:120px' ><span>Funcion</span></td><td></td>";
    cad += "<td style ='width:140px' ><span>Departamento</span></td><td></td>";
    cad += "<td style ='width:120px' ><span>Puesto</span></td><td></td>";
    cad += "<td style ='width:90px' ><span>Paterno</span></td><td></td>";
    cad += "<td style ='width:90px' ><span>Materno</span></td><td></td>";
    cad += "<td style ='width:100px' ><span>Nombre</span></td><td></td>";
    cad += "<td style ='width:80px' ><span>Clave RH</span></td><td></td>";
    cad += "<td style ='width:100px' ><span>Sin cuadrilla</span></td><td></td>";
    cad += "<td rowspan= '2'><input type='button' id = 'Btn_buscar_empleado' onclick = 'buscar_empleados_BE();' value = 'Buscar' /> </td>";
    cad += "</tr><tr>";
    cad += "<td style ='width:120px'><select id = 'ls_funcion_BE' style = 'width:100%' > </select></td><td></td>";
    cad += "<td style ='width:140px'><select id = 'ls_departamento_BE' style = 'width:100%' > </select></td><td></td>";
    cad += "<td style ='width:120px'><select id = 'ls_puesto_BE' style = 'width:100%' > </select></td><td></td>";
    cad += "<td style ='width:90px'><input id = 'txt_paterno_BE' style = 'width:100%' /></td><td></td>";
    cad += "<td style ='width:90px'><input id = 'txt_materno_BE' style = 'width:100%' /></td><td></td>";
    cad += "<td style ='width:100px'><input id = 'txt_nombre_BE' style = 'width:100%' /></td><td></td>";
    cad += "<td style ='width:80px'><input id = 'txt_RH' style = 'width:100%' /></td><td></td>";
    cad += "<td style ='width:100px' ><input id = 'chk_sin_cuadrilla_BE' type ='checkbox' /> </td><td></td>";
    cad += "</tr></table>";

    cad += "<div id = 'Div_Tbl_Con_Emp_BE' style = 'height: 230px; width: 100%; overflow-x: auto;overflow-y: auto;'></div>";

    document.getElementById("dialog_busqueda_empleado").innerHTML = cad;

    $("#Btn_buscar_empleado").button();

    llenar_ls_cat("13", "", "ls_funcion_BE", false);
    llenar_ls_cat("2", "", "ls_departamento_BE", false);
    llenar_ls_cat("5", "", "ls_puesto_BE", false);

    $("#dialog_busqueda_empleado").dialog({ height: 400, width: 900, modal: true, autoOpen: false,
        buttons:
                    [
                       {
                           text: "Aceptar", click: function () {
                               var wdt = recuperar_opc_sel("Tbl_Con_Emp_BE");
                               if (wdt.Rows.length >= 1) {
                                   wId = wdt.Rows[0]["IdEmpleado"].toString();
                                   resp = SAGEP.Ax_Empleados.buscar_empleado(wId);
                                   $(this).dialog("close");
                                   aceptar_bus_emp(resp.value);
                                   resp = SAGEP.Ax_Empleados.buscar_cuentas_empleados(wId, "");
                                   wdt = resp.value;
                                   if (wdt != null && wdt.Rows != null) {
                                       crear_tabla(wdt, "Tbl_Cuentas");

                                   }
                                   else {
                                       alert("¡ Error al consultar los datos !");
                                   }
                               }

                           }
                       },
                       {
                           text: "Cancelar",
                           click: function () {
                               cancelar_bus_emp();
                               $(this).dialog("close");
                           }
                       }
                    ]
    });      //fin inicializacion
    $("#dialog_busqueda_empleado").dialog("open");
}


function buscar_empleados_BE() {
    wFuncion = document.getElementById("ls_funcion_BE").value;
    wDepto = document.getElementById("ls_departamento_BE").value;
    wPuesto = document.getElementById("ls_puesto_BE").value;
    wPaterno = document.getElementById("txt_paterno_BE").value;
    wMaterno = document.getElementById("txt_materno_BE").value;
    wNombre = document.getElementById("txt_nombre_BE").value;
    wSin_Cuadrilla = document.getElementById("chk_sin_cuadrilla_BE").value;
    wRH = document.getElementById("txt_RH").value;
    resp = SAGEP.Ax_Empleados.buscar_empleados(wFuncion, wDepto, wPuesto, wPaterno, wMaterno, wNombre, "", wRH, "", wSin_Cuadrilla);
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        crear_tabla(wdt, "Tbl_Con_Emp_BE");

    }
    else {
        alert("¡ Error al consultar los datos !");
    }

}

function buscar_empleados_TEST() {
    wPaterno = document.getElementById("txt_paterno_BE").value;
    wMaterno = document.getElementById("txt_materno_BE").value;
    wNombre = document.getElementById("txt_nombre_BE").value;
    resp = SAGEP.Ax_Prueba_Empleados.buscar_empleados(wPaterno, wMaterno, wNombre, "");
    wdt = resp.value;
    if (wdt != null && wdt.Rows != null) {
        crear_tabla(wdt, "Tbl_Con_Emp_BE");

    }
    else {
        alert("¡ Error al consultar los datos !");
    }

}