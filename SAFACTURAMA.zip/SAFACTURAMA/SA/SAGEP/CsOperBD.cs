﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Globalization;

namespace SAGEP
{
    public class CsOperBD
    {

        CsABDSQL con = new CsABDSQL();
        private string wSQL = string.Empty;
        private string wMsj = string.Empty;
        private string wparametros = string.Empty;
        const string quote = "\"";
        const string blank = "";

        public string Msj
        { get { return wMsj; } }

        public bool Conecto_BD()
        {
            try
            {
                if (con.StartCnx()) return true;
                else { wMsj = con.Error; return false; }
            }
            catch (Exception e) { wMsj = e.Message; return false; }
        }
        public void Cierro_Cnx()
        { con.Close(); }
        public bool Abro_DataSet(ref DataSet dta, string wSQL, bool wAbroCnx)
        {
            try
            {
                if (wAbroCnx) { if (!Conecto_BD()) { return false; } }
                dta = con.ExecSelect(wSQL);
                if (dta != null)
                {
                    if (wAbroCnx) { Cierro_Cnx(); }
                    return true;
                }
                else { if (wAbroCnx) { Cierro_Cnx(); } return false; }
            }
            catch (Exception e) { wMsj = e.Message; if (wAbroCnx) Cierro_Cnx(); return false; }
        }
        public bool Abro_DataTable(ref DataTable dta, string wSQL, bool wAbroCnx)
        {
            try
            {
                if (wAbroCnx) { if (!Conecto_BD()) { return false; } }
                dta = con.ExecSelectTable(wSQL);
                if (dta != null)
                {
                    if (wAbroCnx) { Cierro_Cnx(); }
                    return true;
                }
                else { if (wAbroCnx) { Cierro_Cnx(); } return false; }
            }
            catch (Exception e) { wMsj = e.Message; if (wAbroCnx) Cierro_Cnx(); return false; }
        }
        public bool Ejecuto_Exec(string wSQL)
        {
            int wregsAfec = 0;
            try
            {
                wregsAfec = con.Exec(wSQL);
                if (wregsAfec >= 0) return true;
                else { wMsj = con.Error; return false; }

            }
            catch (Exception e) { wMsj = e.Message; return false; }
        }
        public bool Recupero_nuevo_id(string wnombre_id, string wtabla, bool wAbroCnx, ref long wnew_id)
        {
            DataSet dtaNewId = null;
            wnew_id = -1;
            //wSQL = "Select isnull(max(" + wnombre_id + "),0)+1 as new_id From " + wtabla;
            wSQL = "Select isnull(max(" + "CAST(" + wnombre_id + " as Int)" + "),0)+1 as new_id From " + wtabla;
            try
            {
                if (Abro_DataSet(ref dtaNewId, wSQL, wAbroCnx))  //wAbroCnx es falso por que este metodo se debe usar dentro de una transacción
                {
                    wnew_id = long.Parse(dtaNewId.Tables[0].Rows[0]["new_id"].ToString());
                    return true;
                }
                else { wMsj = con.Error; return false; }
            }
            catch (Exception e) { wMsj = e.Message; return false; }
        }



        public class Contactos
        {
            CsOperBD ConBD = new CsOperBD();
            string Cad_SQL;
            string Cad_Where;


            public String agregar_contacto(string wIdC,string wNombre, string wApPaterno, string wApMaterno, string wTelefono, string wCelular, string wDomicilio, string wEmail)
            {
                string wIdContacto = "";
                long wId = 0;
                try
                {
                    if (!ConBD.Conecto_BD()) return "¡No se pudo establecer la conexión con la BD!";
                    if (!ConBD.con.BeginTrans()) return "¡No se pudo iniciar la transacción!";
                    if (wIdC == "")
                    {
                        Cad_SQL = "INSERT INTO Contactos (Nombre,ApPaterno,ApMaterno,Domicilio,Email,Celular,Telefono)VALUES('" + wNombre + "','" + wApPaterno + "', '" + wApMaterno + "', '" + wDomicilio + "', '" + wEmail + "', '" + wCelular + "', '" + wTelefono + "');";

                    }
                    else
                    {
                        Cad_SQL = "UPDATE Contactos set Nombre='" + wNombre + "', ApPaterno='" + wApPaterno + "', ApMaterno='" + wApMaterno +
                      "', Domicilio='" + wDomicilio + "', Email='" + wEmail + "', Telefono='" + wTelefono + "',Celular='"+ wCelular+"' WHERE IdContacto=" + wIdC;

                    }
                    
                    if (ConBD.Ejecuto_Exec(Cad_SQL))
                    {
                        ConBD.con.AcceptTrans();
                        if (wIdC == "")
                        {
                            if (ConBD.Recupero_nuevo_id("IdArticulo", "ArticulosDes", false, ref wId))
                            {
                                wIdContacto = (wId - 1).ToString();
                            }

                            ConBD.Cierro_Cnx();
                            return "Id:" + wIdContacto;
                        }
                        else
                        {
                           
                            ConBD.Cierro_Cnx();
                            return "";
                        }
                        
                    }
                    else
                    {
                        ConBD.con.RollBackTrans();
                        ConBD.Cierro_Cnx();
                        return ConBD.con.Error;
                    }

                }
                catch (Exception e)
                {
                    ConBD.con.RollBackTrans();
                    ConBD.Cierro_Cnx();
                    return e.Message;
                }

            }
            public DataTable buscar_contacto(string wIdContacto)
            {
                //return null;
                Cad_Where = " WHERE 1 = 1 ";
                if (wIdContacto != "") Cad_Where += " and IdContacto = " + wIdContacto;


                DataSet Ds = null;
                Cad_SQL = "SELECT IdContacto as Id_Contacto,Nombre,ApPaterno as Apellido_Paterno,ApMaterno as Apellido_Materno,Domicilio,Email,Telefono, Celular FROM Contactos " + Cad_Where + " ORDER BY IdContacto,Nombre";
                if (ConBD.Abro_DataSet(ref Ds, Cad_SQL, true))
                {

                }
                return Ds.Tables[0];
            }
            public String editar_contacto(string wIdContacto, string wNombre, string wApPaterno, string wApMaterno, string wTelefono, string wDomicilio, string wEmail)
            {
                string dt = DateTime.Now.ToString("yyyy-MM-dd");

                try
                {
                    if (!ConBD.Conecto_BD()) return "¡No se pudo establecer la conexión con la BD!";
                    if (!ConBD.con.BeginTrans()) return "¡No se pudo iniciar la transacción!";

                    Cad_SQL = "UPDATE Contactos set Nombre='" + wNombre + "', ApPaterno='" + wApPaterno + "', ApMaterno='" + wApMaterno +
                        "', Domicilio='" + wDomicilio + "', Email='" + wEmail + "', Telefono='" + wTelefono + "' WHERE IdContacto=" + wIdContacto;

                    if (ConBD.Ejecuto_Exec(Cad_SQL))
                    {
                        ConBD.con.AcceptTrans();
                        ConBD.Cierro_Cnx();
                        return "";
                    }
                    else
                    {
                        ConBD.con.RollBackTrans();
                        ConBD.Cierro_Cnx();
                        return ConBD.con.Error;
                    }

                }
                catch (Exception e)
                {
                    ConBD.con.RollBackTrans();
                    ConBD.Cierro_Cnx();
                    return e.Message;
                }

            }
            public String borrar_Contacto(string wIdContacto)
            {

                if (ConBD.Conecto_BD())
                {
                    if (!ConBD.con.BeginTrans()) { return "¡No se pudo iniciar la transacción!"; }
                    Cad_SQL = "DELETE FROM Contactos WHERE IdContacto = " + wIdContacto;
                    if (ConBD.Ejecuto_Exec(Cad_SQL))
                    {
                        ConBD.con.AcceptTrans();
                        ConBD.Cierro_Cnx();
                        return "";
                    }
                    else
                    {
                        ConBD.con.RollBackTrans();
                        ConBD.Cierro_Cnx();
                        return ConBD.con.Error;
                    }
                }
                else
                {
                    return "¡No se pudo establecer la conexión con la BD!";
                }
            }

        }



    }
}
