﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;


namespace SAGEP
{
    public class CsABDSQL
    {
        private SqlConnection wSQLCnx;
        private SqlTransaction wSQLTran;
        private bool wSQLActive;
        private string wError;

        //private string wCnxString = @"data source = SVRGEPAPL\BDGEP; initial catalog = GEPBD; user id = AdmGEP; password =G3p@dM1632";
        //private string wCnxString = @"data source = SVRGEPAPL\BDGEP0; initial catalog = master; user id = AdmGEP; password =G3p@dM1632";        
        //private string wCnxString = @"data source = 192.168.0.251; initial catalog = Geprime; user id = sa; password =Gep#2016@";
        //private string wCnxString = @"data source = SVRGEPAPL\BDGEP0; initial catalog = GEP; user id = usersys; password =us";
        /// <summary>
        /// Cadena de conexion
        /// </summary>
        //NUEVA
        private string wCnxString = @"data source = 192.168.0.249\BDGEP0; initial catalog = SAGEP; user id = usGEP; password =ug";
        //private string wCnxString = @"data source = 192.168.0.249\BDGEP0; initial catalog = GEP; user id = usGEP; password =ug";
        //private string wCnxString = @"data source = DESKTOP-MOSS21T\SQLEXPRESS; initial catalog = GEP; user id = usGEP; password =ug";
        //Ale  private string wCnxString = @"Data Source=DESKTOP-KJ5TOJG\SQLEXPRESS;Initial Catalog=GEP;Integrated Security=True";
        //private string wCnxString = @"Data Source=LAPTOP-HRMIBCQA\SQLEXPRESS;Initial Catalog=GEP;Integrated Security=True";
        
        public CsABDSQL()
        { wSQLActive = false; }
        

        /// <summary>
        /// regresa el error
        /// </summary>
        public string Error
        { get { return wError; } }
        

        /// <summary>
        /// regresa la transaccion de la consulta
        /// </summary>
        /// <returns></returns>
        public bool BeginTrans()
        {
            if (!wSQLActive) return false;
            try
            {
                wSQLTran = wSQLCnx.BeginTransaction();
                return true;
            }
            catch (Exception e) { wError = e.Message; wSQLTran = null; return false; }
        }
        

        /// <summary>
        /// Acepta la transaccion de la consulta
        /// </summary>
        /// <returns></returns>
        public bool AcceptTrans()
        {
            if (!wSQLActive ) return false;
            try
            {
                wSQLTran.Commit();
                wSQLTran = null;
                return true;
            }
            catch (Exception e) { wError = e.Message; return false; }

        }
        
        /// <summary>
        /// regresa la transaccion ya que no se pudo realizar
        /// </summary>
        /// <returns></returns>
        public bool RollBackTrans()
        {
            if (!wSQLActive ) return false;
            try
            {
                wSQLTran.Rollback();
                wSQLTran = null;
                return true;
            }
            catch (Exception e) { wError = e.Message; wSQLTran = null; return false; }
        }
        

        /// <summary>
        /// abre la conexion 
        /// </summary>
        /// <returns></returns>
        public bool StartCnx()
        {
            try
            {
                wSQLCnx = new SqlConnection(wCnxString);
                wSQLCnx.Open();
                wSQLActive = true;
                return true;
            }
            catch (Exception e) { wError = e.Message; return false; }
        }
       
        /// <summary>
        /// Cierra la conexion
        /// </summary>
        public void Close()
        { wSQLActive = false;
        try
        {
            wSQLCnx.Close();
        }
        catch (Exception e) { wError = e.Message;  }
        }
       
        /// <summary>
        /// Ejecuta la cadena sql 
        /// </summary>
        /// <param name="wquery">Cadena sql</param>
        /// <returns>Devuelve un DataSet con los datos de la consulta</returns>
        public DataSet ExecSelect(string wquery)
        {
            DataSet dtaSet;
            SqlDataAdapter wSqlDataAdapter;
            SqlCommand wSQLComm;
            if (!wSQLActive) return null;
            try
            {
                wSQLComm = new SqlCommand(wquery, wSQLCnx);
                wSQLComm.Transaction = wSQLTran;
                wSQLComm.CommandTimeout = 0;
                wSqlDataAdapter = new SqlDataAdapter(wSQLComm);
                dtaSet = new DataSet();
                wSqlDataAdapter.Fill(dtaSet, "tabla");
                return dtaSet;

            }
            catch (Exception e) { wError = e.Message; return null; }
        }

        public DataTable ExecSelectTable(string wquery)
        {
            DataTable dtaSet;
            SqlDataAdapter wSqlDataAdapter;
            SqlCommand wSQLComm;
            if (!wSQLActive) return null;
            try
            {
                wSQLComm = new SqlCommand(wquery, wSQLCnx);
                wSQLComm.Transaction = wSQLTran;
                wSQLComm.CommandTimeout = 0;
                wSqlDataAdapter = new SqlDataAdapter(wSQLComm);
                dtaSet = new DataTable();
                wSqlDataAdapter.Fill(dtaSet);
                // wSqlDataAdapter.Fill(dtaSet, "tabla");
                return dtaSet;

            }
            catch (Exception e) { wError = e.Message; return null; }
        }
        /// <summary>
        /// Ejecuta el sql
        /// </summary>
        /// <param name="wquery">Cadena sql</param>
        /// <returns></returns>
        public int Exec(string wquery)
        {
            SqlCommand wSQLComm;
            if (!wSQLActive) return -1;
            try
            {
                wSQLComm = new SqlCommand(wquery, wSQLCnx);
                wSQLComm.CommandTimeout = 0;
                wSQLComm.Transaction = wSQLTran;
                return wSQLComm.ExecuteNonQuery();
            }
            catch (Exception e) { wError = e.Message; return -1; }
        }

    }
}