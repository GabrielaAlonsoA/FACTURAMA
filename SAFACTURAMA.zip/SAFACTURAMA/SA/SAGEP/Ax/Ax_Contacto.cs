﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AjaxPro;
using System.Data;



namespace SAGEP
{
    public class Ax_Contacto
    {

        CsOperBD.Contactos CsOper = new CsOperBD.Contactos();
        string Msg = "";

        [AjaxMethod]
        public String agregar_contacto(string wId,string wNombre, string wApPaterno, string wApMaterno, string wTelefono, string wCelular, string wDomicilio, string wEmail)
        {
            string resp = "";
            resp = CsOper.agregar_contacto(wId,wNombre, wApPaterno, wApMaterno, wTelefono, wCelular, wDomicilio, wEmail);
            return resp;
        }

        [AjaxMethod]
        public DataTable buscar_contacto(string wIdContacto)
        {
            DataTable Dt;
            Dt = CsOper.buscar_contacto(wIdContacto);
            return Dt;
        }

        [AjaxMethod]
        public String editar_contacto(string wIdContacto, string wNombre, string wApPaterno, string wApMaterno, string wTelefono, string wDomicilio, string wEmail)
        {
            string resp = "";
            resp = CsOper.editar_contacto(wIdContacto, wNombre, wApPaterno, wApMaterno, wTelefono, wDomicilio, wEmail);
            return resp;
        }

        [AjaxMethod]
        public String borrar_Contacto(string wIdContacto)
        {
            string resp = "";
            resp = CsOper.borrar_Contacto(wIdContacto);
            return resp;
        }


    }
}