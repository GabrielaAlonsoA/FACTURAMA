﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace SAGEP
{
    public partial class Cotizaciones : System.Web.UI.Page
    {
        
        CsOperBD Utl_BD = new CsOperBD();
        protected void Page_Load(object sender, EventArgs e)
        {
                    AjaxPro.Utility.RegisterTypeForAjax(typeof(Ax_Contacto));
                   
        }


        protected void AsyncFileUpload1_UploadedComplete(object sender, AjaxControlToolkit.AsyncFileUploadEventArgs e)
        {
            //long idInsertedLayout = 0;

            if (AsyncFileUpload1.HasFile)
            {
                string wCmd = "";
                try
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "size", "top.$get(\"" + lblStatus.ClientID + "\").innerHTML = 'Cargando archivo: " + AsyncFileUpload1.FileBytes.Length.ToString() + "';", true);
                    if (Utl_BD.Conecto_BD() == false)
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "error", "top.$get(\"" + lblStatus.ClientID + "\").innerHTML = 'Error: " + Utl_BD.Msj + "';", true);
                        return;
                    }

                    string nombre_archivo = "", url = "";

                    string fec_hra;
                    fec_hra = DateTime.Now.ToString("dd-MM-yyyy");
                    nombre_archivo = fec_hra.ToString() + Path.GetFileName(e.FileName);
                    url = "Docs/Cotizaciones/"+ nombre_archivo;
                    // 
                    wCmd = "INSERT INTO BitacoraDocCotizaciones(URL,IdUsuario,IdCotizacion)VALUES('" + url + "'," + lbl_id.InnerHtml + "," + txt_cot.Value + ")";
                    if (Utl_BD.Ejecuto_Exec(wCmd))
                    {
                        Utl_BD.Cierro_Cnx();
                        string strPath = HttpContext.Current.Server.MapPath("Docs/Cotizaciones");
                        if (Directory.Exists(strPath) == false)
                        {
                            Directory.CreateDirectory(strPath);

                        }
                        strPath += "/" + nombre_archivo; //Path.GetFileName(e.FileName);
                        AsyncFileUpload1.SaveAs(strPath);
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", "top.$get(\"" + lblStatus.ClientID + "\").innerHTML = '';", true);

                    }
                    

                }
                catch (Exception er)
                {
                    Utl_BD.Cierro_Cnx();
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "error", "top.$get(\"" + lblStatus.ClientID + "\").innerHTML = 'Error: " + er.Message + "';", true);
                }
            }
        }


       /* protected void AsyncFileUpload1_UploadedComplete(object sender, AjaxControlToolkit.AsyncFileUploadEventArgs e)
        {
            //long idInsertedLayout = 0;

            if (AsyncFileUpload1.HasFile)
            {
                string wCmd = "";
                try
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "size", "top.$get(\"" + lblStatus.ClientID + "\").innerHTML = 'Cargando archivo: " + AsyncFileUpload1.FileBytes.Length.ToString() + "';", true);
                    if (Utl_BD.Conecto_BD() == false)
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "error", "top.$get(\"" + lblStatus.ClientID + "\").innerHTML = 'Error: " + Utl_BD.Msj + "';", true);
                        return;
                    }

                    string nombre_archivo = "";

                    long fec_hra;
                    fec_hra = DateTime.Now.Ticks;


                    string extension = System.IO.Path.GetExtension(e.FileName);
                    string extensionValida = "." + Formato.Value;
                    String wAnualidad = anualidad.Value;
                    String widPronostico = IdPronostico.Value;

                    // Allow only files with .doc or .xls extensions
                    // to be uploaded.
                    if (extension == extensionValida || extension == extensionValida.ToLower() || extension == extensionValida.ToUpper())
                    {
                        //nombre_archivo = fec_hra.ToString() + Path.GetFileName(e.FileName);
                        nombre_archivo = "Resp" + wAnualidad + widPronostico + fec_hra.ToString() + extension;

                        wCmd = "INSERT INTO DocRespaldoPronostico (IdPronostico,IdFormato,UrlDocumento,IdUsuario) VALUES('" + widPronostico + "','" + IdFormato.Value + "','" + nombre_archivo + "','" + IdUsr.Value + "')";
                        if (Utl_BD.Ejecuto_Exec(wCmd))
                        {
                            Utl_BD.Cierro_Cnx();
                            string strPath = HttpContext.Current.Server.MapPath("Docs/Pronosticos/Resp" + anualidad.Value);
                            if (Directory.Exists(strPath) == false)
                            {
                                Directory.CreateDirectory(strPath);

                            }
                            strPath += "/" + nombre_archivo; //Path.GetFileName(e.FileName);
                            AsyncFileUpload1.SaveAs(strPath);
                            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", "top.$get(\"" + lblStatus.ClientID + "\").innerHTML = '';", true);
                        }
                        else
                        {
                            Utl_BD.Cierro_Cnx();
                            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "error", "top.$get(\"" + lblStatus.ClientID + "\").innerHTML = 'Error: " + Utl_BD.Msj + "';", true);
                        }
                    }
                    else
                    {
                        Utl_BD.Cierro_Cnx();
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "error", "top.$get(\"" + lblStatus.ClientID + "\").innerHTML = 'Error: El formato del archivo no es válido.';", true);
                    }

                }
                catch (Exception er)
                {
                    Utl_BD.Cierro_Cnx();
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "error", "top.$get(\"" + lblStatus.ClientID + "\").innerHTML = 'Error: " + er.Message + "';", true);
                }
            }
        }*/

    }
}